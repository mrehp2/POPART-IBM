/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


/* To do: decide if we want to add in a function to initialize community-specific params.
 * 
 */


/************************************************************************/
/******************************* Includes  ******************************/
/************************************************************************/

#include "input.h"
#include "constants.h"
#include "utilities.h"

/************************************************************************/
/******************************** functions *****************************/
/************************************************************************/

/* These are the functions in this file:
 * read_param() - function which calls each of the individual read_params() functions:
 * read_demographic_params() - read in demographic parameters from param_demographics.txt
 * read_hiv_params() - read in hiv-related (transmission, progression) parameters from param_HIV.txt
 * read_partnership_params() - read in partnership parameters from param_partnerships.txt
 * read_time_params() - read in time-related parameters (start of epidemic, start of ART etc) from param_times.txt
 * read_cascade_params() - read in HIV cascade-related parameters from param_cascade.txt
 * read_initial_params() - read in initial conditions (population size, etc) from init_param.txt
We also currently keep the old ones for comparison.
*/



/******************************************************************************/
/* Functions to read parameter values and fill the values in the param structure.
 * arguments: file_directory: the name of the directory where the parameter files ("param.txt") are stored.
 * 					this is a subdirectory of popart-ibm-code/popart-code/IBM-simul/
 *            param: a pointer to the "parameters" structure where parameters values will be stored once read from the files.                          */
/******************************************************************************/

/* This function calls all other functions to read in from each file: */
void read_param(char * file_directory, parameters * param, int n_runs){
	/*****  */

	read_demographic_params(file_directory, param, n_runs);
	read_hiv_params(file_directory, param, n_runs);
	read_partnership_params(file_directory, param, n_runs);
	read_time_params(file_directory, param, n_runs);
	read_cascade_params(file_directory, param, n_runs);
	read_initial_params(file_directory,param, n_runs);   /* Read in the parameters related to initial conditions. */

}
	
/**********************************************************************/
/****************    Read in demographic parameters    ****************/
/**********************************************************************/
void read_demographic_params(char * file_directory, parameters *allrunparameters, int n_runs){	
	FILE * param_file;
	char param_file_name[100];
	int i_run;
	
	/* This is a local temp variable we use so we don't have to keep writing allparameters+i_run (or equivalently &allparameters[i_run]). */
	parameters *param_local;
	
	/*******************  adding path before file name ********************/

	strncpy(param_file_name,file_directory,100);
	strcat(param_file_name, "/param_processed_demographics.txt");

	/******************* opening parameter file ********************/
	if ((param_file=fopen(param_file_name,"r"))==NULL)
	{
		printf("Cannot open param_processed_demographics.txt");
		fflush(stdout);
		exit(1);
	}else
	{
		printf("Demographics parameters read from: %s:\n",param_file_name);
	}

	/******************* read parameters from each line i_run ********************/
	for (i_run = 0; i_run<n_runs; i_run++){
		param_local = allrunparameters + i_run;
		fscanf(param_file,"%lg",&(param_local->total_fertility_rate));
		fscanf(param_file,"%lg",&(param_local->shape_fertility_param));
		fscanf(param_file,"%lg",&(param_local->scale_fertility_param));
		fscanf(param_file,"%lg",&(param_local->sex_ratio));                                                            
	}
	/******************* closing parameter file ********************/
	fclose(param_file);

}

/**********************************************************************/
/******************* Read in  HIV parameters     **********************/
/**********************************************************************/
void read_hiv_params(char * file_directory, parameters *allrunparameters, int n_runs){
	FILE * param_file;
	char param_file_name[100];
	int i_run;
	double temp;
	int spvl;
	int icd4;
	double p_misclassify_cd4[NCD4];
	
	/* This is a local temp variable we use so we don't have to keep writing allparameters+i_run (or equivalently &allparameters[i_run]). */
	parameters *param_local;
		
		
	strncpy(param_file_name,file_directory,100);
	strcat(param_file_name, "/param_processed_HIV.txt");

	/******************* opening parameter file ********************/
	if ((param_file=fopen(param_file_name,"r"))==NULL)
	{
		printf("Cannot open param_processed_HIV.txt");
		fflush(stdout);
		exit(1);
	}else
	{
		printf("HIV parameters read from: %s:\n",param_file_name);
	}


			
	/******************* read parameters from each line i_run ********************/
	for (i_run = 0; i_run<n_runs; i_run++){
		param_local = allrunparameters + i_run;

		fscanf(param_file,"%lg",&(param_local->p_child_circ));
	
		fscanf(param_file,"%lg",&(param_local->eff_circ));
		fscanf(param_file,"%lg",&(param_local->rr_circ_unhealed));
		fscanf(param_file,"%lg",&(param_local->t0_pmtct));
		fscanf(param_file,"%lg",&(param_local->t50_pmtct));
		fscanf(param_file,"%lg",&(param_local->average_log_viral_load));
		fscanf(param_file,"%lg",&(param_local->average_annual_hazard));
		fscanf(param_file,"%lg",&(param_local->RRacute_trans));
		fscanf(param_file,"%lg",&(param_local->RRmale_to_female_trans));
		fscanf(param_file,"%lg %lg %lg %lg",&(param_local->RRCD4[0]),&(param_local->RRCD4[1]),&(param_local->RRCD4[2]),&(param_local->RRCD4[3]));
		fscanf(param_file,"%lg %lg %lg %lg",&(param_local->RRSPVL[0]),&(param_local->RRSPVL[1]),&(param_local->RRSPVL[2]),&(param_local->RRSPVL[3]));
	
		/* Calculate RR in infectivity from effectiveness of initial ART, ART when VS and ART when not VS. */
		
		fscanf(param_file,"%lg",&temp);
		/* Reduction in infectivity is 1- (effectiveness) */
		param_local->RR_ART_INITIAL = 1.0 - temp;
			
		fscanf(param_file,"%lg",&temp);
		param_local->RR_ART_VS = 1.0 - temp;
		
		fscanf(param_file,"%lg",&temp);
		param_local->RR_ART_VU = 1.0 - temp;
			
		fscanf(param_file,"%lg %lg",&(param_local->min_dur_acute),&(param_local->max_dur_acute));
		
	
		for (spvl=0; spvl<NSPVL;spvl++){
			fscanf(param_file,"%lg",&(param_local->p_initial_cd4_gt500[spvl]));
			fscanf(param_file,"%lg",&(param_local->p_initial_cd4_350_500[spvl]));
			fscanf(param_file,"%lg",&(param_local->p_initial_cd4_200_350[spvl]));
			fscanf(param_file,"%lg",&(param_local->p_initial_cd4_lt200[spvl]));
		
			/* Ensure these are normalized to sum to 1: */
			normalise_four_quantities(&param_local->p_initial_cd4_gt500[spvl], &param_local->p_initial_cd4_350_500[spvl], &param_local->p_initial_cd4_200_350[spvl], &param_local->p_initial_cd4_lt200[spvl]);
			//printf("Normalized values = %f %f %f %f\n",param_local->p_initial_cd4_gt500[spvl], param_local->p_initial_cd4_350_500[spvl], param_local->p_initial_cd4_200_350[spvl], param_local->p_initial_cd4_lt200[spvl]);	
			/* Now to save recomputing these, make cumulative sums: */
			cumulative_four_quantities(param_local->p_initial_cd4_gt500[spvl], param_local->p_initial_cd4_350_500[spvl], param_local->p_initial_cd4_200_350[spvl], param_local->p_initial_cd4_lt200[spvl],&param_local->cumulative_p_initial_cd4_gt500[spvl],&param_local->cumulative_p_initial_cd4_350_500[spvl],&param_local->cumulative_p_initial_cd4_200_350[spvl],&param_local->cumulative_p_initial_cd4_lt200[spvl]); 
			//printf("Cumulative values = %f %f %f %f\n",param_local->cumulative_p_initial_cd4_gt500[spvl],param_local->cumulative_p_initial_cd4_350_500[spvl],param_local->cumulative_p_initial_cd4_200_350[spvl],param_local->cumulative_p_initial_cd4_lt200[spvl]);
		}

		for (spvl=0; spvl<NSPVL;spvl++){
			fscanf(param_file,"%lg",&(param_local->p_initial_spvl_cat[spvl]));
		}
		normalise_four_quantities(&param_local->p_initial_spvl_cat[0],&param_local->p_initial_spvl_cat[1],&param_local->p_initial_spvl_cat[2],&param_local->p_initial_spvl_cat[3]);
		cumulative_four_quantities(param_local->p_initial_spvl_cat[0],param_local->p_initial_spvl_cat[1],param_local->p_initial_spvl_cat[2],param_local->p_initial_spvl_cat[3],&param_local->cumulative_p_initial_spvl_cat[0],&param_local->cumulative_p_initial_spvl_cat[1],&param_local->cumulative_p_initial_spvl_cat[2],&param_local->cumulative_p_initial_spvl_cat[3]);
		//printf("Cumulative SPVL values = %f %f %f %f\n",param_local->cumulative_p_initial_spvl_cat[0],param_local->cumulative_p_initial_spvl_cat[1],param_local->cumulative_p_initial_spvl_cat[2],param_local->cumulative_p_initial_spvl_cat[3]);
		
	
		/* For a given true CD4 p_misclassify_cd4[j] stores the probability that the measured cd4 cat is j. */ 
			
		/* Note that icd4 is the true cd4, and the other index is the measured cd4. */
		for (icd4=0; icd4<NCD4; icd4++){
			
			fscanf(param_file,"%lg %lg %lg %lg", &(p_misclassify_cd4[0]), &(p_misclassify_cd4[1]), &(p_misclassify_cd4[2]), &(p_misclassify_cd4[3]));
			normalise_four_quantities(&(p_misclassify_cd4[0]), &(p_misclassify_cd4[1]), &(p_misclassify_cd4[2]), &(p_misclassify_cd4[3]));
			cumulative_four_quantities(p_misclassify_cd4[0], p_misclassify_cd4[1], p_misclassify_cd4[2], p_misclassify_cd4[3], &param_local->cumulative_p_misclassify_cd4[icd4][0],&param_local->cumulative_p_misclassify_cd4[icd4][1],&param_local->cumulative_p_misclassify_cd4[icd4][2],&param_local->cumulative_p_misclassify_cd4[icd4][3]);
			//if (PRINT_DEBUG_INPUT)
			//printf("Cumulative CD4 misclassification values: %lg %lg %lg %lg\n", param_local->cumulative_p_misclassify_cd4[icd4][0], param_local->cumulative_p_misclassify_cd4[icd4][1], param_local->cumulative_p_misclassify_cd4[icd4][2], param_local->cumulative_p_misclassify_cd4[icd4][3]);
		}	
	
		
		for (spvl=0; spvl<NSPVL;spvl++){
			for (icd4=0; icd4<NCD4; icd4++){
				/* Get min and max. */
				fscanf(param_file,"%lg %lg",&param_local->time_hiv_event[icd4][spvl][0],&(param_local->time_hiv_event[icd4][spvl][1]));
			}
		}
		
		fscanf(param_file,"%lg",&(param_local->factor_for_slower_progression_ART_VU));
	
	}	
	
	/******************* closing parameter file ********************/
	fclose(param_file);
}


/**********************************************************************/
/*******************     Partnership parameters    ********************/
/**********************************************************************/
void read_partnership_params(char * file_directory, parameters *allrunparameters, int n_runs){
	FILE * param_file;
	int g, ag, r, bg;
	char param_file_name[100];
	int i_run;
	/* This is a local temp variable we use so we don't have to keep writing allparameters+i_run (or equivalently &allparameters[i_run]). */
	parameters *param_local;

	
	strncpy(param_file_name,file_directory,100);
	strcat(param_file_name, "/param_processed_partnerships.txt");

	/******************* opening parameter file ********************/
	if ((param_file=fopen(param_file_name,"r"))==NULL)
	{
		printf("Cannot open param_processed_partnerships.txt");
		fflush(stdout);
		exit(1);
	}else
	{
		printf("Partnership parameters read from: %s:\n",param_file_name);
	}

	/******************* read parameters from each line i_run ********************/
	for (i_run = 0; i_run<n_runs; i_run++){
		param_local = allrunparameters + i_run;

	
		fscanf(param_file,"%lg",&(param_local->assortativity));
		fscanf(param_file,"%lg",&(param_local->prop_compromise_from_males));
		
		for(ag=0 ; ag<N_AGE ; ag++)
		{
			fscanf(param_file,"%lg",&(param_local->c_per_gender[FEMALE][ag]));
		}
		
		for(ag=0 ; ag<N_AGE ; ag++)
		{
			fscanf(param_file,"%lg",&(param_local->c_per_gender[MALE][ag]));
		}
	
		for(r=0 ; r<N_RISK ; r++)
		{
			fscanf(param_file,"%lg",&(param_local->relative_number_partnerships_per_risk[r]));
		}
	
		for(g=0 ; g<N_GENDER ; g++)
		{
			for(ag=0 ; ag<N_AGE ; ag++)
			{
				for(bg=0 ; bg<N_AGE ; bg++)
				{
					fscanf(param_file,"%lg",&(param_local->p_age_per_gender[g][ag][bg]));
				}
			}
		}


		for(r=0 ; r<N_RISK ; r++)
		{
			fscanf(param_file,"%d",&(param_local->max_n_part_noage[r]));
		}
		
		fscanf(param_file,"%lg",&(param_local->breakup_scale_lambda));
		fscanf(param_file,"%lg",&(param_local->breakup_shape_k));

		
	}
	/******************* closing parameter file ********************/
	fclose(param_file);
}




/**********************************************************************/
/*******************     Time-related parameters    ********************/
/**********************************************************************/

void read_time_params(char * file_directory, parameters *allrunparameters, int n_runs){
	FILE * param_file;
	char param_file_name[100];
	int i_run;
	/* This is a local temp variable we use so we don't have to keep writing allparameters+i_run (or equivalently &allparameters[i_run]). */
	parameters *param_local;
	
	strncpy(param_file_name,file_directory,100);
	strcat(param_file_name, "/param_processed_times.txt");

	/******************* opening parameter file ********************/
	if ((param_file=fopen(param_file_name,"r"))==NULL)
	{
		printf("Cannot open param_processed_times.txt");
		fflush(stdout);
		exit(1);
	}else
	{
		if (PRINT_DEBUG_INPUT)
			printf("Times parameters read from: %s:\n",param_file_name);
	}

	/******************* read parameters from each line i_run ********************/
	for (i_run = 0; i_run<n_runs; i_run++){
		param_local = allrunparameters + i_run;

		fscanf(param_file,"%lg",&(param_local->start_time_hiv));
		fscanf(param_file,"%d",&(param_local->start_time_simul));
		fscanf(param_file,"%d",&(param_local->end_time_simul));
		fscanf(param_file,"%lg",&(param_local->COUNTRY_HIV_TEST_START));
		fscanf(param_file,"%lg",&(param_local->COUNTRY_ART_START));
		fscanf(param_file,"%lg",&(param_local->COUNTRY_VMMC_START));
		fscanf(param_file,"%lg",&(param_local->POPART_START));
		fscanf(param_file,"%lg",&(param_local->POPART_END));
			
			
		if( (int) (param_local->start_time_simul) != (param_local->start_time_simul) || (int) (param_local->end_time_simul) != param_local->end_time_simul)
		{
			printf("start_time_simul and end_time_simul defined in 'param_times.txt' should be integers. Execution aborted.");
			exit(1);
		}
	
		if( param_local->end_time_simul - param_local->start_time_simul > MAX_N_YEARS )
		{
			printf("MAX_N_YEARS < param_local->end_time_simul - param_local->start_time_simul. Need to increase the value of MAX_N_YEARS. Execution aborted.");
			exit(1);
		}
	}
	/******************* closing parameter file ********************/
	fclose(param_file);
}



/**********************************************************************/
/*******************     Cascade parameters    ********************/
/**********************************************************************/
void read_cascade_params(char * file_directory, parameters *allrunparameters, int n_runs){
	FILE * param_file;
	int icd4;
	char param_file_name[100];
	int i_run;
	double max_temp;  /* Local variable which allows us to get the range from the max value. */
	/* This is a local temp variable we use so we don't have to keep writing allparameters+i_run (or equivalently &allparameters[i_run]). */
	parameters *param_local;
	
	strncpy(param_file_name,file_directory,100);
	strcat(param_file_name, "/param_processed_cascade.txt");

	/******************* opening parameter file ********************/
	if ((param_file=fopen(param_file_name,"r"))==NULL)
	{
		printf("Cannot open param_processed_cascade.txt");
		fflush(stdout);
		exit(1);
	}else
	{
		if (PRINT_DEBUG_INPUT)
			printf("Cascade parameters read from: %s:\n",param_file_name);
	}

	/******************* read parameters from each line i_run ********************/
	for (i_run = 0; i_run<n_runs; i_run++){
		param_local = allrunparameters + i_run;

		/* Input probabilities for the cascade events: */
		fscanf(param_file,"%lg",&(param_local->p_collect_hiv_test_results_cd4_over200));
		fscanf(param_file,"%lg",&(param_local->p_collect_hiv_test_results_cd4_under200));
		fscanf(param_file,"%lg",&(param_local->p_collect_cd4_test_results_cd4_over200));
		fscanf(param_file,"%lg",&(param_local->p_collect_cd4_test_results_cd4_under200));
		for (icd4=0; icd4<NCD4; icd4++){
			fscanf(param_file,"%lg",&(param_local->p_dies_earlyart_cd4[icd4]));
		}
	
		fscanf(param_file,"%lg",&(param_local->p_leaves_earlyart_cd4_over200));	
		fscanf(param_file,"%lg",&(param_local->p_leaves_earlyart_cd4_under200));
		fscanf(param_file,"%lg",&(param_local->p_becomes_vs_after_earlyart));
		fscanf(param_file,"%lg",&(param_local->p_stays_virally_suppressed));
		fscanf(param_file,"%lg",&(param_local->p_stops_virally_suppressed));
		fscanf(param_file,"%lg",&(param_local->p_vu_becomes_virally_suppressed));
		/* Input times for the cascade events: */
		fscanf(param_file,"%lg",&(param_local->t_earlyart_dropout_min[NOTPOPART]));
		fscanf(param_file,"%lg",&max_temp); 
		param_local->t_earlyart_dropout_range[NOTPOPART] = max_temp - param_local->t_earlyart_dropout_min[NOTPOPART];
		fscanf(param_file,"%lg",&(param_local->t_earlyart_dropout_min[POPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_earlyart_dropout_range[POPART]    = max_temp - param_local->t_earlyart_dropout_min[POPART];
		
		fscanf(param_file,"%lg",&(param_local->t_dies_earlyart_min[NOTPOPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_dies_earlyart_range[NOTPOPART] = max_temp - param_local->t_dies_earlyart_min[NOTPOPART];
		fscanf(param_file,"%lg",&(param_local->t_dies_earlyart_min[POPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_dies_earlyart_range[POPART]    = max_temp - param_local->t_dies_earlyart_min[POPART];
		fscanf(param_file,"%lg",&(param_local->t_end_early_art));
		fscanf(param_file,"%lg",&(param_local->t_cd4_retest_min[NOTPOPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_cd4_retest_range[NOTPOPART] = max_temp - param_local->t_cd4_retest_min[NOTPOPART];
		fscanf(param_file,"%lg",&(param_local->t_cd4_retest_min[POPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_cd4_retest_range[POPART]    = max_temp - param_local->t_cd4_retest_min[POPART]; 
		fscanf(param_file,"%lg",&(param_local->t_cd4_whenartfirstavail_min));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_cd4_whenartfirstavail_range = max_temp - param_local->t_cd4_whenartfirstavail_min;
		
		fscanf(param_file,"%lg",&(param_local->t_delay_hivtest_to_cd4test_min[NOTPOPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_delay_hivtest_to_cd4test_range[NOTPOPART] = max_temp - param_local->t_delay_hivtest_to_cd4test_min[NOTPOPART];
		fscanf(param_file,"%lg",&(param_local->t_delay_hivtest_to_cd4test_min[POPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_delay_hivtest_to_cd4test_range[POPART]    = max_temp - param_local->t_delay_hivtest_to_cd4test_min[POPART];

		
		
		
		fscanf(param_file,"%lg",&(param_local->t_start_art_min[NOTPOPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_start_art_range[NOTPOPART] = max_temp - param_local->t_start_art_min[NOTPOPART];
		fscanf(param_file,"%lg",&(param_local->t_start_art_min[POPART]));	
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_start_art_range[POPART] = max_temp - param_local->t_start_art_min[POPART];
		
		fscanf(param_file,"%lg",&(param_local->t_end_vs_becomevu_min[NOTPOPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_end_vs_becomevu_range[NOTPOPART] = max_temp - param_local->t_end_vs_becomevu_min[NOTPOPART];
		fscanf(param_file,"%lg",&(param_local->t_end_vs_becomevu_min[POPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_end_vs_becomevu_range[POPART] = max_temp - param_local->t_end_vs_becomevu_min[POPART];
		
		fscanf(param_file,"%lg",&(param_local->t_end_vs_dropout_min[NOTPOPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_end_vs_dropout_range[NOTPOPART] = max_temp - param_local->t_end_vs_dropout_min[NOTPOPART];
		fscanf(param_file,"%lg",&(param_local->t_end_vs_dropout_min[POPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_end_vs_dropout_range[POPART] = max_temp -  param_local->t_end_vs_dropout_min[POPART];
		
		fscanf(param_file,"%lg",&(param_local->t_end_vu_becomevs_min[NOTPOPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_end_vu_becomevs_range[NOTPOPART] = max_temp - param_local->t_end_vu_becomevs_min[NOTPOPART];
		fscanf(param_file,"%lg",&(param_local->t_end_vu_becomevs_min[POPART]));	
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_end_vu_becomevs_range[POPART] = max_temp - param_local->t_end_vu_becomevs_min[POPART];
		
		fscanf(param_file,"%lg",&(param_local->t_end_vu_dropout_min[NOTPOPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_end_vu_dropout_range[NOTPOPART] = max_temp - param_local->t_end_vu_dropout_min[NOTPOPART];  
			
		fscanf(param_file,"%lg",&(param_local->t_end_vu_dropout_min[POPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_end_vu_dropout_range[POPART] = max_temp - param_local->t_end_vu_dropout_min[POPART];  
		/* This is the probability of getting back into the cascade during PopART for someone who 
		 * dropped out before PopART. */
		fscanf(param_file,"%lg",&(param_local->p_popart_to_cascade));
		fscanf(param_file,"%lg",&(param_local->p_circ[NOTPOPART]));
		fscanf(param_file,"%lg",&(param_local->p_circ[POPART]));
		fscanf(param_file,"%lg",&(param_local->t_get_vmmc_min[NOTPOPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_get_vmmc_range[NOTPOPART] = max_temp - param_local->t_get_vmmc_min[NOTPOPART];
		
		fscanf(param_file,"%lg",&(param_local->t_get_vmmc_min[POPART]));
		fscanf(param_file,"%lg",&max_temp);
		param_local->t_get_vmmc_range[POPART] = max_temp - param_local->t_get_vmmc_min[POPART];
		fscanf(param_file,"%lg",&(param_local->t_vmmc_healing));
		fscanf(param_file,"%lg",&(param_local->prop_visited_by_chips[MALE]));
		fscanf(param_file,"%lg",&(param_local->prop_visited_by_chips[FEMALE]));
		param_local->prop_visited_by_chips[FEMALE] = param_local->prop_visited_by_chips[MALE];

	}
	printf("For Pangea we are forcing the proportion visited by CHiPs to be the same for men and women. \n");
	/******************* closing parameter file ********************/
	fclose(param_file);

}




/***** function does: read initial condition parameter values from init_param.txt in file_directory and fills those values in param
 ***** arguments: file_directory: a pointer to the name of the directory where the file containing the parameters ("init_param.txt") is stored in
 * 					this is a subdirectory of .../popart-ibm-code/popart-code/IBM-simul/
 *                param: a pointer to the "parameters" structure where parameters values will be stored in once read in the file
 ***** function returns: nothing. */
void read_initial_params(char *file_directory, parameters *allrunparameters, int n_runs)
{
	FILE *init_param_file;

	/* Indices for age group (0..N_AGE-1), risk and gender. */
	int ag,r,g;

	double checksum;
	
	int i_run;
	/* This is a local temp variable we use so we don't have to keep writing allparameters+i_run (or equivalently &allparameters[i_run]). */
	parameters *param_local;
	
	/*******************  adding path before file name ********************/
	char init_param_file_name[100];
	strncpy(init_param_file_name,file_directory,100);
	strcat(init_param_file_name, "/init_param_processed.txt");

	/******************* opening parameter file ********************/
	if ((init_param_file=fopen(init_param_file_name,"r"))==NULL){
		printf("Cannot open init_param_processed.txt");
		fflush(stdout);
		exit(1);
	}
	else
		printf("Parameters read from: %s:\n",init_param_file_name);

	/******************* read parameters from each line i_run ********************/
	for (i_run = 0; i_run<n_runs; i_run++){
		param_local = allrunparameters + i_run;

		fscanf(init_param_file,"%lg",&(param_local->initial_population_size));                                                            
		for (ag=0; ag<N_AGE; ag++){
			fscanf(init_param_file,"%lg",&(param_local->initial_prop_age[ag]));                                             
		}
	
		/* This loads the proportion of the total population who is of gender k and risk group r. */
		for (r=0; r<N_RISK; r++){
			for (g=0; g<N_GENDER; g++){
				fscanf(init_param_file,"%lg",&(param_local->initial_prop_gender_risk[g][r]));                                                  
			}
		}
	
		/* This loads the proportion of gender-risk specific population who is HIV+ at time of HIV introduction */
		for (r=0; r<N_RISK; r++){
			for (g=0; g<N_GENDER; g++){
				fscanf(init_param_file,"%lg",&(param_local->initial_prop_infected_gender_risk[g][r]));
			}
		}
	
		
		fscanf(init_param_file,"%d",&(param_local->cluster_number));                                                            
	
		//printf("Cluster number: %d\n",param_local->cluster_number);
	
		
		////// This is for debugging: 
		////// Make sure proportions add to 1.
		////// Shall we do it this way or have only 2 of the 3 read in a file and automatically calculating the third one? Could then print the third one to warn the user
	
		for (g=0; g<N_GENDER; g++){
			checksum = 0.0;
			for (r=0; r<N_RISK; r++)
				checksum += param_local->initial_prop_gender_risk[g][r];
			if (fabs(checksum-1.0)>1e-12){
				printf("Sum of proportions of initial population by risk is not 1 %f.\n",checksum);
				exit(1);
			}
		}
		checksum = 0;
		for (ag=0; ag<N_AGE; ag++)
			checksum += param_local->initial_prop_age[ag];
		if (checksum!=1.0){
			printf("Sum of proportions of initial population by age is not 1.\n");
			exit(1);
		}
	
		/* End of debugging. */
	}
	
	fclose(init_param_file);


}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// OLD CODE ///
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

/**********************************************************************/
/****************    Read in demographic parameters    ****************/
/**********************************************************************/
void read_demographic_params_old(char * file_directory, parameters *param, int n_runs){	
	FILE * param_file;
	char names[100]; /* to read names of parameters in parameter files (not used after reading) */
	char param_file_name[100];
	
	
	/*******************  adding path before file name ********************/

	strncpy(param_file_name,file_directory,100);
	strcat(param_file_name, "/param_demographics.txt");

	/******************* opening parameter file ********************/
	if ((param_file=fopen(param_file_name,"r"))==NULL)
	{
		printf("Cannot open param_demographics.txt");
		fflush(stdout);
		exit(1);
	}else
	{
		printf("Demographics parameters read from: %s:\n",param_file_name);
	}


	/******************* read parameters ********************/

	fscanf(param_file,"%s %lg",names,&(param->total_fertility_rate));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->total_fertility_rate);

	fscanf(param_file,"%s %lg",names,&(param->shape_fertility_param));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->shape_fertility_param);

	fscanf(param_file,"%s %lg",names,&(param->scale_fertility_param));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->scale_fertility_param);

	fscanf(param_file,"%s %lg",names,&(param->sex_ratio));                                                            
		if (PRINT_DEBUG_INPUT)
			printf("%s %lg\n",names,param->sex_ratio);

	printf("-------------------------------------\n");
	fflush(stdout);

	/******************* closing parameter file ********************/
	fclose(param_file);

}

/**********************************************************************/
/******************* Read in  HIV parameters     **********************/
/**********************************************************************/
void read_hiv_params_old(char * file_directory, parameters * param, int n_runs){
	FILE * param_file;
	char names[100]; /* to read names of parameters in parameter files (not used after reading) */
	char param_file_name[100];

	
	strncpy(param_file_name,file_directory,100);
	strcat(param_file_name, "/param_HIV.txt");

	/******************* opening parameter file ********************/
	if ((param_file=fopen(param_file_name,"r"))==NULL)
	{
		printf("Cannot open param_HIV.txt");
		fflush(stdout);
		exit(1);
	}else
	{
		printf("HIV parameters read from: %s:\n",param_file_name);
	}

	/******************* read parameters ********************/

	fscanf(param_file,"%s %lg",names,&(param->p_child_circ));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->p_child_circ);

	fscanf(param_file,"%s %lg",names,&(param->eff_circ));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->eff_circ);

	fscanf(param_file,"%s %lg",names,&(param->rr_circ_unhealed));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->rr_circ_unhealed);
	
	fscanf(param_file,"%s %lg",names,&(param->t0_pmtct));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t0_pmtct);

	fscanf(param_file,"%s %lg",names,&(param->t50_pmtct));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t50_pmtct);

	fscanf(param_file,"%s %lg",names,&(param->average_log_viral_load));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->average_log_viral_load);

	fscanf(param_file,"%s %lg",names,&(param->average_annual_hazard));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->average_annual_hazard);

	fscanf(param_file,"%s %lg",names,&(param->RRacute_trans));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->RRacute_trans);

	fscanf(param_file,"%s %lg",names,&(param->RRmale_to_female_trans));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->RRmale_to_female_trans);
	
	fscanf(param_file,"%s %lg %lg %lg %lg",names,&(param->RRCD4[0]),&(param->RRCD4[1]),&(param->RRCD4[2]),&(param->RRCD4[3]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg %lg %lg %lg\n",names,param->RRCD4[0],param->RRCD4[1],param->RRCD4[2],param->RRCD4[3]);
	fscanf(param_file,"%s %lg %lg %lg %lg",names,&(param->RRSPVL[0]),&(param->RRSPVL[1]),&(param->RRSPVL[2]),&(param->RRSPVL[3]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg %lg %lg %lg\n",names,param->RRSPVL[0],param->RRSPVL[1],param->RRSPVL[2],param->RRSPVL[3]);

	/* Calculate RR in infectivity from effectiveness of initial ART, ART when VS and ART when not VS. */
	double temp;
	fscanf(param_file,"%s %lg",names,&temp);
	/* Reduction in infectivity is 1- (effectiveness) */
	param->RR_ART_INITIAL = 1.0 - temp;
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg \n",names,param->RR_ART_INITIAL);
		
	fscanf(param_file,"%s %lg",names,&temp);
	param->RR_ART_VS = 1.0 - temp;
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg \n",names,param->RR_ART_VS);
	
	fscanf(param_file,"%s %lg",names,&temp);
	param->RR_ART_VU = 1.0 - temp;
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg \n",names,param->RR_ART_VU);
		
	fscanf(param_file,"%s %lg %lg",names,&(param->min_dur_acute),&(param->max_dur_acute));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg %lg\n",names,param->min_dur_acute,param->max_dur_acute);
	
	int spvl;
	for (spvl=0; spvl<NSPVL;spvl++){
		fscanf(param_file,"%s %lg",names,&(param->p_initial_cd4_gt500[spvl]));
		if (PRINT_DEBUG_INPUT)
			printf("%s %lg\n",names,param->p_initial_cd4_gt500[spvl]);
		fscanf(param_file,"%s %lg",names,&(param->p_initial_cd4_350_500[spvl]));
		if (PRINT_DEBUG_INPUT)
			printf("%s %lg\n",names,param->p_initial_cd4_350_500[spvl]);
		fscanf(param_file,"%s %lg",names,&(param->p_initial_cd4_200_350[spvl]));
		if (PRINT_DEBUG_INPUT)
			printf("%s %lg\n",names,param->p_initial_cd4_200_350[spvl]);
		fscanf(param_file,"%s %lg",names,&(param->p_initial_cd4_lt200[spvl]));
		if (PRINT_DEBUG_INPUT)
			printf("%s %lg\n",names,param->p_initial_cd4_lt200[spvl]);
	
		/* Ensure these are normalized to sum to 1: */
		normalise_four_quantities(&param->p_initial_cd4_gt500[spvl], &param->p_initial_cd4_350_500[spvl], &param->p_initial_cd4_200_350[spvl], &param->p_initial_cd4_lt200[spvl]);
		printf("Normalized values = %f %f %f %f\n",param->p_initial_cd4_gt500[spvl], param->p_initial_cd4_350_500[spvl], param->p_initial_cd4_200_350[spvl], param->p_initial_cd4_lt200[spvl]);	
		/* Now to save recomputing these, make cumulative sums: */
		cumulative_four_quantities(param->p_initial_cd4_gt500[spvl], param->p_initial_cd4_350_500[spvl], param->p_initial_cd4_200_350[spvl], param->p_initial_cd4_lt200[spvl],&param->cumulative_p_initial_cd4_gt500[spvl],&param->cumulative_p_initial_cd4_350_500[spvl],&param->cumulative_p_initial_cd4_200_350[spvl],&param->cumulative_p_initial_cd4_lt200[spvl]); 
		printf("Cumulative values = %f %f %f %f\n",param->cumulative_p_initial_cd4_gt500[spvl],param->cumulative_p_initial_cd4_350_500[spvl],param->cumulative_p_initial_cd4_200_350[spvl],param->cumulative_p_initial_cd4_lt200[spvl]);
	}

	for (spvl=0; spvl<NSPVL;spvl++){
		fscanf(param_file,"%s %lg",names,&(param->p_initial_spvl_cat[spvl]));
			if (PRINT_DEBUG_INPUT)
				printf("%s %lg\n",names,param->p_initial_spvl_cat[spvl]);
	}
	normalise_four_quantities(&param->p_initial_spvl_cat[0],&param->p_initial_spvl_cat[1],&param->p_initial_spvl_cat[2],&param->p_initial_spvl_cat[3]);
	cumulative_four_quantities(param->p_initial_spvl_cat[0],param->p_initial_spvl_cat[1],param->p_initial_spvl_cat[2],param->p_initial_spvl_cat[3],&param->cumulative_p_initial_spvl_cat[0],&param->cumulative_p_initial_spvl_cat[1],&param->cumulative_p_initial_spvl_cat[2],&param->cumulative_p_initial_spvl_cat[3]);
	printf("Cumulative SPVL values = %f %f %f %f\n",param->cumulative_p_initial_spvl_cat[0],param->cumulative_p_initial_spvl_cat[1],param->cumulative_p_initial_spvl_cat[2],param->cumulative_p_initial_spvl_cat[3]);
	
	int icd4;
	/* For a given true CD4 p_misclassify_cd4[j] stores the probability that the measured cd4 cat is j. */ 
	double p_misclassify_cd4[NCD4];
	/* Note that icd4 is the true cd4, and the other index is the measured cd4. */
	for (icd4=0; icd4<NCD4; icd4++){
		
		fscanf(param_file,"%s %lg %lg %lg %lg",names, &(p_misclassify_cd4[0]), &(p_misclassify_cd4[1]), &(p_misclassify_cd4[2]), &(p_misclassify_cd4[3]));
		normalise_four_quantities(&(p_misclassify_cd4[0]), &(p_misclassify_cd4[1]), &(p_misclassify_cd4[2]), &(p_misclassify_cd4[3]));
		cumulative_four_quantities(p_misclassify_cd4[0], p_misclassify_cd4[1], p_misclassify_cd4[2], p_misclassify_cd4[3], &param->cumulative_p_misclassify_cd4[icd4][0],&param->cumulative_p_misclassify_cd4[icd4][1],&param->cumulative_p_misclassify_cd4[icd4][2],&param->cumulative_p_misclassify_cd4[icd4][3]);
		//if (PRINT_DEBUG_INPUT)
		printf("Cumulative CD4 misclassification values: %s %lg %lg %lg %lg\n",names, param->cumulative_p_misclassify_cd4[icd4][0], param->cumulative_p_misclassify_cd4[icd4][1], param->cumulative_p_misclassify_cd4[icd4][2], param->cumulative_p_misclassify_cd4[icd4][3]);
	}	

	
	for (spvl=0; spvl<NSPVL;spvl++){
		for (icd4=0; icd4<NCD4; icd4++){
			/* Get min and max. */
			fscanf(param_file,"%s %lg %lg",names,&param->time_hiv_event[icd4][spvl][0],&(param->time_hiv_event[icd4][spvl][1]));
			if (PRINT_DEBUG_INPUT)
				printf("%s %lg %lg\n",names,param->time_hiv_event[icd4][spvl][0],param->time_hiv_event[icd4][spvl][1]);
		}
	}
	
	fscanf(param_file,"%s %lg",names,&(param->factor_for_slower_progression_ART_VU));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->factor_for_slower_progression_ART_VU);
	
	
	printf("-------------------------------------\n");
	fflush(stdout);

	/******************* closing parameter file ********************/
	fclose(param_file);
}


/**********************************************************************/
/*******************     Partnership parameters    ********************/
/**********************************************************************/
void read_partnership_params_old(char * file_directory, parameters * param, int n_runs){
	FILE * param_file;
	char names[100]; /* to read names of parameters in parameter files (not used after reading) */
	int g, ag, r, bg;
	char param_file_name[100];

	strncpy(param_file_name,file_directory,100);
	strcat(param_file_name, "/param_partnerships.txt");

	/******************* opening parameter file ********************/
	if ((param_file=fopen(param_file_name,"r"))==NULL)
	{
		printf("Cannot open param_partnerships.txt");
		fflush(stdout);
		exit(1);
	}else
	{
		printf("Partnership parameters read from: %s:\n",param_file_name);
	}

	/******************* read parameters ********************/

	fscanf(param_file,"%s %lg",names,&(param->assortativity));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->assortativity);

	fscanf(param_file,"%s %lg",names,&(param->prop_compromise_from_males));
	
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->prop_compromise_from_males);

	fscanf(param_file,"%s", names);
	if (PRINT_DEBUG_INPUT)
		printf("%s ",names);
	for(ag=0 ; ag<N_AGE ; ag++)
	{
		fscanf(param_file,"%lg",&(param->c_per_gender[FEMALE][ag]));
		if (PRINT_DEBUG_INPUT)
			printf("%lg\t",param->c_per_gender[FEMALE][ag]);
	}
	if (PRINT_DEBUG_INPUT)
		printf("\n");

	fscanf(param_file,"%s", names);
	if (PRINT_DEBUG_INPUT)
		printf("%s ",names);
	for(ag=0 ; ag<N_AGE ; ag++)
	{
		fscanf(param_file,"%lg",&(param->c_per_gender[MALE][ag]));
		if (PRINT_DEBUG_INPUT)
			printf("%lg\t",param->c_per_gender[MALE][ag]);
	}
	if (PRINT_DEBUG_INPUT)
		printf("\n");

	fscanf(param_file,"%s", names);
	if (PRINT_DEBUG_INPUT)
		printf("%s ",names);
	for(r=0 ; r<N_RISK ; r++)
	{
		fscanf(param_file,"%lg",&(param->relative_number_partnerships_per_risk[r]));
		if (PRINT_DEBUG_INPUT)
			printf("%lg\t",param->relative_number_partnerships_per_risk[r]);
	}
	if (PRINT_DEBUG_INPUT)
		printf("\n");

	for(g=0 ; g<N_GENDER ; g++)
	{
		for(ag=0 ; ag<N_AGE ; ag++)
		{
			fscanf(param_file,"%s", names);
			if (PRINT_DEBUG_INPUT)
				printf("%s ",names);
			for(bg=0 ; bg<N_AGE ; bg++)
			{

				fscanf(param_file,"%lg",&(param->p_age_per_gender[g][ag][bg]));
				if (PRINT_DEBUG_INPUT)
					printf("%lg\t",param->p_age_per_gender[g][ag][bg]);
			}
			if (PRINT_DEBUG_INPUT)
				printf("\n");
		}
	}
	if (PRINT_DEBUG_INPUT){
		printf("-------------------------------------\n");
		fflush(stdout);
	}
	
	/******************* closing parameter file ********************/
	fclose(param_file);
}




/**********************************************************************/
/*******************     Time-related parameters    ********************/
/**********************************************************************/

void read_time_params_old(char * file_directory, parameters * param, int n_runs){
	FILE * param_file;
	char names[100]; /* to read names of parameters in parameter files (not used after reading) */
	char param_file_name[100];
	strncpy(param_file_name,file_directory,100);
	strcat(param_file_name, "/param_times.txt");

	/******************* opening parameter file ********************/
	if ((param_file=fopen(param_file_name,"r"))==NULL)
	{
		printf("Cannot open param_times.txt");
		fflush(stdout);
		exit(1);
	}else
	{
		if (PRINT_DEBUG_INPUT)
			printf("Times parameters read from: %s:\n",param_file_name);
	}

	/******************* read parameters ********************/

	fscanf(param_file,"%s %lg",names,&(param->start_time_hiv));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->start_time_hiv);

	fscanf(param_file,"%s %d",names,&(param->start_time_simul));
	if (PRINT_DEBUG_INPUT)
		printf("%s %d\n",names,param->start_time_simul);

	fscanf(param_file,"%s %d",names,&(param->end_time_simul));
	if (PRINT_DEBUG_INPUT)
		printf("%s %d\n",names,param->end_time_simul);
	
	fscanf(param_file,"%s %lg",names,&(param->COUNTRY_HIV_TEST_START));
		if (PRINT_DEBUG_INPUT)
			printf("%s %lg\n",names,param->COUNTRY_HIV_TEST_START);
		
	fscanf(param_file,"%s %lg",names,&(param->COUNTRY_ART_START));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->COUNTRY_ART_START);
	
	fscanf(param_file,"%s %lg",names,&(param->COUNTRY_VMMC_START));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->COUNTRY_VMMC_START);			
	
	fscanf(param_file,"%s %lg",names,&(param->POPART_START));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->POPART_START);		

	fscanf(param_file,"%s %lg",names,&(param->POPART_END));
	//if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->POPART_END);	
		
		
	if( (int) (param->start_time_simul) != (param->start_time_simul) || (int) (param->end_time_simul) != param->end_time_simul)
	{
		printf("start_time_simul and end_time_simul defined in 'param_times.txt' should be integers. Execution aborted.");
		exit(1);
	}

	if( param->end_time_simul - param->start_time_simul > MAX_N_YEARS )
	{
		printf("MAX_N_YEARS < param->end_time_simul - param->start_time_simul. Need to increase the value of MAX_N_YEARS. Execution aborted.");
		exit(1);
	}

	if (PRINT_DEBUG_INPUT){
		printf("-------------------------------------\n");
		fflush(stdout);
	}
	/******************* closing parameter file ********************/
	fclose(param_file);
}



/**********************************************************************/
/*******************     Cascade parameters    ********************/
/**********************************************************************/
void read_cascade_params_old(char * file_directory, parameters * param, int n_runs){
	FILE * param_file;
	char names[100]; /* to read names of parameters in parameter files (not used after reading) */
	//int g, ag, r, bg;
	int icd4;
	char param_file_name[100];
	
	strncpy(param_file_name,file_directory,100);
	strcat(param_file_name, "/param_cascade.txt");

	/******************* opening parameter file ********************/
	if ((param_file=fopen(param_file_name,"r"))==NULL)
	{
		printf("Cannot open param_cascade.txt");
		fflush(stdout);
		exit(1);
	}else
	{
		if (PRINT_DEBUG_INPUT)
			printf("Cascade parameters read from: %s:\n",param_file_name);
	}

	/******************* read parameters ********************/

	/* Input probabilities for the cascade events: */
	fscanf(param_file,"%s %lg",names,&(param->p_collect_hiv_test_results_cd4_over200));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->p_collect_hiv_test_results_cd4_over200);

	fscanf(param_file,"%s %lg",names,&(param->p_collect_hiv_test_results_cd4_under200));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->p_collect_hiv_test_results_cd4_under200);

	fscanf(param_file,"%s %lg",names,&(param->p_collect_cd4_test_results_cd4_over200));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->p_collect_cd4_test_results_cd4_over200);

	fscanf(param_file,"%s %lg",names,&(param->p_collect_cd4_test_results_cd4_under200));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->p_collect_cd4_test_results_cd4_under200);

	for (icd4=0; icd4<NCD4; icd4++){
		fscanf(param_file,"%s %lg",names,&(param->p_dies_earlyart_cd4[icd4]));
		if (PRINT_DEBUG_INPUT)
			printf("%s %lg\n",names,param->p_dies_earlyart_cd4[icd4]);
	}

	fscanf(param_file,"%s %lg",names,&(param->p_leaves_earlyart_cd4_over200));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->p_leaves_earlyart_cd4_over200);
	
	fscanf(param_file,"%s %lg",names,&(param->p_leaves_earlyart_cd4_under200));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->p_leaves_earlyart_cd4_under200);

	fscanf(param_file,"%s %lg",names,&(param->p_becomes_vs_after_earlyart));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->p_becomes_vs_after_earlyart);
	
	fscanf(param_file,"%s %lg",names,&(param->p_stays_virally_suppressed));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->p_stays_virally_suppressed);

	fscanf(param_file,"%s %lg",names,&(param->p_stops_virally_suppressed));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->p_stops_virally_suppressed);
		
	fscanf(param_file,"%s %lg",names,&(param->p_vu_becomes_virally_suppressed));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->p_vu_becomes_virally_suppressed);	
		
	/* Input times for the cascade events: */
	fscanf(param_file,"%s %lg",names,&(param->t_earlyart_dropout_min[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_earlyart_dropout_min[NOTPOPART]);	
	fscanf(param_file,"%s %lg",names,&(param->t_earlyart_dropout_min[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_earlyart_dropout_min[POPART]);	
	
	fscanf(param_file,"%s %lg",names,&(param->t_earlyart_dropout_range[NOTPOPART])); 
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_earlyart_dropout_range[NOTPOPART]);	
	fscanf(param_file,"%s %lg",names,&(param->t_earlyart_dropout_range[POPART])); 
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_earlyart_dropout_range[POPART]);	
	
	
	fscanf(param_file,"%s %lg",names,&(param->t_dies_earlyart_min[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_dies_earlyart_min[NOTPOPART]);	
	fscanf(param_file,"%s %lg",names,&(param->t_dies_earlyart_min[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_dies_earlyart_min[POPART]);
	
	fscanf(param_file,"%s %lg",names,&(param->t_dies_earlyart_range[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_dies_earlyart_range[NOTPOPART]);
	fscanf(param_file,"%s %lg",names,&(param->t_dies_earlyart_range[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_dies_earlyart_range[POPART]);
	
	fscanf(param_file,"%s %lg",names,&(param->t_end_early_art));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_early_art);	
	
	
	fscanf(param_file,"%s %lg",names,&(param->t_cd4_retest_min[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_cd4_retest_min[NOTPOPART]);	
	fscanf(param_file,"%s %lg",names,&(param->t_cd4_retest_min[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_cd4_retest_min[POPART]);	
	
	fscanf(param_file,"%s %lg",names,&(param->t_cd4_retest_range[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_cd4_retest_range[NOTPOPART]);
	fscanf(param_file,"%s %lg",names,&(param->t_cd4_retest_range[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_cd4_retest_range[POPART]);

	
	fscanf(param_file,"%s %lg",names,&(param->t_cd4_whenartfirstavail_min));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_cd4_whenartfirstavail_min);
	fscanf(param_file,"%s %lg",names,&(param->t_cd4_whenartfirstavail_range));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_cd4_whenartfirstavail_range);
			
	fscanf(param_file,"%s %lg",names,&(param->t_delay_hivtest_to_cd4test_min[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_delay_hivtest_to_cd4test_min[NOTPOPART]);	
	fscanf(param_file,"%s %lg",names,&(param->t_delay_hivtest_to_cd4test_min[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_delay_hivtest_to_cd4test_min[POPART]);
	
	fscanf(param_file,"%s %lg",names,&(param->t_delay_hivtest_to_cd4test_range[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_delay_hivtest_to_cd4test_range[NOTPOPART]);
	fscanf(param_file,"%s %lg",names,&(param->t_delay_hivtest_to_cd4test_range[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_delay_hivtest_to_cd4test_range[POPART]);
	
	
	fscanf(param_file,"%s %lg",names,&(param->t_start_art_min[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_start_art_min[NOTPOPART]);	
	fscanf(param_file,"%s %lg",names,&(param->t_start_art_min[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_start_art_min[POPART]);
	
	fscanf(param_file,"%s %lg",names,&(param->t_start_art_range[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_start_art_range[NOTPOPART]);
	fscanf(param_file,"%s %lg",names,&(param->t_start_art_range[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_start_art_range[POPART]);
	
	fscanf(param_file,"%s %lg",names,&(param->t_end_vs_becomevu_min[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vs_becomevu_min[NOTPOPART]);
	fscanf(param_file,"%s %lg",names,&(param->t_end_vs_becomevu_min[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vs_becomevu_min[POPART]);

	fscanf(param_file,"%s %lg",names,&(param->t_end_vs_becomevu_range[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vs_becomevu_range[NOTPOPART]);
	fscanf(param_file,"%s %lg",names,&(param->t_end_vs_becomevu_range[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vs_becomevu_range[POPART]);

	fscanf(param_file,"%s %lg",names,&(param->t_end_vs_dropout_min[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vs_dropout_min[NOTPOPART]);
	fscanf(param_file,"%s %lg",names,&(param->t_end_vs_dropout_min[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vs_dropout_min[POPART]);
	
	fscanf(param_file,"%s %lg",names,&(param->t_end_vs_dropout_range[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vs_dropout_range[NOTPOPART]);
	fscanf(param_file,"%s %lg",names,&(param->t_end_vs_dropout_range[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vs_dropout_range[POPART]);
		
	fscanf(param_file,"%s %lg",names,&(param->t_end_vu_becomevs_min[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vu_becomevs_min[NOTPOPART]);
	fscanf(param_file,"%s %lg",names,&(param->t_end_vu_becomevs_min[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vu_becomevs_min[POPART]);
	
	fscanf(param_file,"%s %lg",names,&(param->t_end_vu_becomevs_range[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vu_becomevs_range[NOTPOPART]);
	fscanf(param_file,"%s %lg",names,&(param->t_end_vu_becomevs_range[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vu_becomevs_range[POPART]);

	
	
	fscanf(param_file,"%s %lg",names,&(param->t_end_vu_dropout_min[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vu_dropout_min[NOTPOPART]);
	fscanf(param_file,"%s %lg",names,&(param->t_end_vu_dropout_min[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vu_dropout_min[POPART]);
	
	fscanf(param_file,"%s %lg",names,&(param->t_end_vu_dropout_range[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vu_dropout_range[NOTPOPART]);
	fscanf(param_file,"%s %lg",names,&(param->t_end_vu_dropout_range[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_end_vu_dropout_range[POPART]);
	
	/* This is the probability of getting back into the cascade during PopART for someone who 
	 * dropped out before PopART. */
	fscanf(param_file,"%s %lg",names,&(param->p_popart_to_cascade));
	if (PRINT_DEBUG_INPUT)
	printf("%s %lg\n",names,param->p_popart_to_cascade);
	/*
	fscanf(param_file,"%s %lg",names,&(param->));
		if (PRINT_DEBUG_INPUT)
			if (PRINT_DEBUG_INPUT)
					printf("%s %lg\n",names,param->);
				fscanf(param_file,"%s %lg",names,&(param->));
		if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->);
		
		


*/				
	fscanf(param_file,"%s %lg",names,&(param->p_circ[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->p_circ[NOTPOPART]);
	fscanf(param_file,"%s %lg",names,&(param->p_circ[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->p_circ[POPART]);
	
	fscanf(param_file,"%s %lg",names,&(param->t_get_vmmc_min[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_get_vmmc_min[NOTPOPART]);
	fscanf(param_file,"%s %lg",names,&(param->t_get_vmmc_min[POPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_get_vmmc_min[POPART]);
			
	fscanf(param_file,"%s %lg",names,&(param->t_get_vmmc_range[NOTPOPART]));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_get_vmmc_range[NOTPOPART]);
	fscanf(param_file,"%s %lg",names,&(param->t_get_vmmc_range[POPART]));
		if (PRINT_DEBUG_INPUT)
			printf("%s %lg\n",names,param->t_get_vmmc_range[POPART]);
		
	fscanf(param_file,"%s %lg",names,&(param->t_vmmc_healing));
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->t_vmmc_healing);

	

	printf("-------------------------------------\n");
	fflush(stdout);

	/******************* closing parameter file ********************/
	fclose(param_file);

}




/***** function does: read initial condition parameter values from init_param.txt in file_directory and fills those values in param
 ***** arguments: file_directory: a pointer to the name of the directory where the file containing the parameters ("init_param.txt") is stored in
 * 					this is a subdirectory of .../popart-ibm-code/popart-code/IBM-simul/
 *                param: a pointer to the "parameters" structure where parameters values will be stored in once read in the file
 ***** function returns: nothing. */
void read_initial_params_old(char *file_directory, parameters *param, int n_runs)
{

	FILE *init_param_file;
	char names[100]; /* to read names of parameters in parameter files (not used after reading) */

	/* Indices for age group (0..N_AGE-1), risk and gender. */
	int ag,r,g;

	/*******************  adding path before file name ********************/
	char init_param_file_name[100];
	strncpy(init_param_file_name,file_directory,100);
	strcat(init_param_file_name, "/init_param.txt");

	/******************* opening parameter file ********************/
	if ((init_param_file=fopen(init_param_file_name,"r"))==NULL){
		printf("Cannot open init_param.txt");
		fflush(stdout);
		exit(1);
	}
	else
		printf("Parameters read from: %s:\n",init_param_file_name);

	/******************* read parameters ********************/
	fscanf(init_param_file,"%s %lg",names,&(param->initial_population_size));                                                            
	if (PRINT_DEBUG_INPUT)
		printf("%s %lg\n",names,param->initial_population_size);

	for (ag=0; ag<N_AGE; ag++){
		fscanf(init_param_file,"%s %lg",names,&(param->initial_prop_age[ag]));                                             
		if (PRINT_DEBUG_INPUT)
			printf("%s %lg\n",names,param->initial_prop_age[ag]);
	}

	/* This loads the proportion of the total population who is of gender k and risk group r. */
	for (r=0; r<N_RISK; r++){
		for (g=0; g<N_GENDER; g++){
			fscanf(init_param_file,"%s %lg",names,&(param->initial_prop_gender_risk[g][r]));                                                  
			if (PRINT_DEBUG_INPUT)
				printf("%s %lg\n",names,param->initial_prop_gender_risk[g][r]);                                                                     
		}
	}

	/* This loads the proportion of gender-risk specific population who is HIV+ at time of HIV introduction */
	for (r=0; r<N_RISK; r++){
		for (g=0; g<N_GENDER; g++){
			fscanf(init_param_file,"%s %lg",names,&(param->initial_prop_infected_gender_risk[g][r]));
			if (PRINT_DEBUG_INPUT)
				printf("%s %lg\n",names,param->initial_prop_infected_gender_risk[g][r]);
		}
	}

	
	fscanf(init_param_file,"%s %d",names,&(param->cluster_number));                                                            
	//if (PRINT_DEBUG_INPUT)
		printf("%s %d\n",names,param->cluster_number);

	/* Given the cluster number, assign the trial arm (this is currently a global variable, but could stick in param). 
	 * Using numbering from M&E Reports_All Sites thru 30th April 2014-3.xlsx. 
	 * Sites 1,2,5,6,8,9,10,11 are arms A+B Zambia. Of these sites 2,5,8,10 arm A.
	 * Sites 13,14,16,18,19,20 are arms A_B South Africa. Of these sites 14,16,19 arm A. */
	if (param->cluster_number==2 ||param->cluster_number==5 ||param->cluster_number==8 ||param->cluster_number==10 ||param->cluster_number==14 ||param->cluster_number==16 ||param->cluster_number==19)		
		TRIAL_ARM = ARM_A; 
	else if (param->cluster_number==1 || param->cluster_number==6 || param->cluster_number==9 || param->cluster_number==11 || param->cluster_number==13 || param->cluster_number==18 || param->cluster_number==20)
		TRIAL_ARM = ARM_B;
	else
		TRIAL_ARM = ARM_C;
	
	////// This is for debugging: 
	////// Make sure proportions add to 1.
	////// Shall we do it this way or have only 2 of the 3 read in a file and automatically calculating the third one? Could then print the third one to warn the user
	double checksum;
	for (g=0; g<N_GENDER; g++){
		checksum = 0.0;
		for (r=0; r<N_RISK; r++)
			checksum += param->initial_prop_gender_risk[g][r];
		if (fabs(checksum-1.0)>1e-12){
			printf("Sum of proportions of initial population by risk is not 1 %f.\n",checksum);
			exit(1);
		}
	}
	checksum = 0;
	for (ag=0; ag<N_AGE; ag++)
		checksum += param->initial_prop_age[ag];
	if (checksum!=1.0){
		printf("Sum of proportions of initial population by age is not 1.\n");
		exit(1);
	}

	/* End of debugging. */
	if (PRINT_DEBUG_INPUT){
		printf("-------------------------------------\n");
		fflush(stdout);
	}
	fclose(init_param_file);


}


