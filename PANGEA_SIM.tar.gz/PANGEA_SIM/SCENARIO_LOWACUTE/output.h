/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef OUTPUT_H_
#define OUTPUT_H_

#include "structures.h"
#include "demographics.h"
#include "hiv.h"


void print_individual(individual *);
void print_population(population_size *);
void print_population_from_one_year_data(population_size *, population_size_one_year_age *);
void print_population_one_year(population_size_one_year_age *);
void print_population_one_year_only_old(population_size_one_year_age *);
void print_stratified_population(stratified_population_size *);
void print_partners(individual *);
void print_partnership(partnership *);
void print_HIV_status(individual *);
void print_demographics(individual *, population_size *, stratified_population_size *, double );
void print_number_by_age(age_list_struct *);
void print_number_by_age_grouped(age_list_struct *,population_size *, stratified_population_size*);
void update_annual_outputs_gender(individual *, long *, long *, long *, long *, int );
void update_annual_outputs_riskgp(individual *, long *, long *, long *, long *, long *, long *);
void store_annual_outputs(parameters *, individual *, population_size_one_year_age *, population_size_one_year_age *, age_list_struct *, long, cumulative_outputs_struct *, int);
void write_annual_outputs(char *);
void store_phylogenetic_transmission_output(double, individual*, individual*);
void store_phylogenetic_transmission_initial_cases(parameters *, individual*);
void write_phylo_transmission_data(char *);
void write_phylo_individual_data(individual *, char *);
#endif /* OUTPUT_H_ */
