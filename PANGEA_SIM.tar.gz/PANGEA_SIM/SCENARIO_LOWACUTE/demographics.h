/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef DEMOGRAPHICS_H_
#define DEMOGRAPHICS_H_

#include "structures.h"


double per_woman_fertility_rate(int, parameters *, double, int);
double natural_death_rate(int, double, parameters *);
int draw_sex_risk(int, parameters *);
void create_new_individual(individual *, double , parameters *, int, population_partners *, population_size *, population_size_one_year_age *);
void update_population_size_new_adult(individual *, population_size *, stratified_population_size *);
void update_population_size_death(individual *, population_size *, population_size_one_year_age *, stratified_population_size *, int, age_list_struct *);
void initialize_first_cascade_event_for_new_individual(individual *, double , parameters *, individual ***, long *, long *);
void update_age_list_new_adult(age_list_struct *, individual *);
void update_age_list_death(age_list_struct *, int, long, double );
int get_age_index(double , double );
int get_age_group(double , double );
void update_n_population_ageing_by_one_year(age_list_struct *, population_size *);
void age_population_by_one_year(age_list_struct *);
void update_pop_available_partners_ageing_by_one_year(age_list_struct *, population_partners *, population_size *, double );
void age_population_size_one_year_age_by_one_year(population_size_one_year_age *);
void remove_dead_person_from_susceptible_in_serodiscordant_partnership(individual *, individual **, long *);
void remove_dead_person_from_list_available_partners(double, individual *,population_partners *, population_size *);
void remove_dead_persons_partners(individual *, population_partners *, population_size *, double );
void remove_from_hiv_pos_progression(individual *, individual ***, long *, long *, double , parameters *);
void remove_from_cascade_events(individual *, individual ***, long *, long *, double , parameters *);
void remove_from_vmmc_events(individual *, individual ***, long *, long *, double , parameters *);
void deaths_natural_causes(age_list_struct *, individual *, population_size *, population_size_one_year_age *, stratified_population_size *, double , parameters *, long *, long *, individual **, long *, population_partners *, population_size *, individual ***, long *, long *, individual ***, long *, long *, individual ***, long *, long *);
void make_new_adults(child_population_struct *, individual *, population_size *, stratified_population_size *, age_list_struct *, double , parameters *, population_partners *, population_size *, population_size_one_year_age *,  individual ***, long *, long *);
void add_new_kids(child_population_struct *, population_size *, stratified_population_size *, parameters *, double, int);
void make_pop_from_age_list(population *, age_list_struct *, individual *);
void individual_death_AIDS(age_list_struct *, individual *, population_size *,  population_size_one_year_age *, stratified_population_size *, double , parameters *, individual **, long *, population_partners *, population_size *, individual ***, long *, long *);
#endif /* DEMOGRAPHICS_H_ */
