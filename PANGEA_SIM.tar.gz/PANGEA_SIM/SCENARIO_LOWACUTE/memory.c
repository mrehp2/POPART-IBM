/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


/*Functions:
 * void reinitialize_arrays_to_default() - at the start of a new run set all necessary pointers to zero.
 *
 */


/************************************************************************/
/******************************* Includes  ******************************/
/************************************************************************/

#include "memory.h"


/************************************************************************/
/******************************** functions *****************************/
/************************************************************************/
void reinitialize_arrays_to_default(long *death_dummylist, long *partner_dummylist, long *n_partnerships, 
		long *n_susceptible_in_serodiscordant_partnership, long *n_hiv_pos_progression, 
		long *size_hiv_pos_progression, long *n_cascade_events, long *size_cascade_events, 
		long *n_vmmc_events, long *size_vmmc_events, long *n_planned_breakups,long *size_planned_breakups){
	long i;
	for (i=0; i<MAX_N_PER_AGE_GROUP; i++)
		death_dummylist[i] = i;         /* Initialize the dummy list. */

	for (i=0; i<MAX_N_PER_AGE_GROUP*MAX_PARTNERSHIPS_PER_INDIVIDUAL; i++)
		partner_dummylist[i] = i;         /* Initialize the dummy list. */
	*n_partnerships = 0;
	*n_susceptible_in_serodiscordant_partnership = 0;
	/* Initialise the number of people in each group to be zero (as no HIV at start of simulation): */
	for (i=0; i<MAX_N_YEARS*N_TIME_STEP_PER_YEAR; i++)
		n_hiv_pos_progression[i] = 0;

	/* Initialise the  size of the arrays to the default: */
	for (i=0; i<MAX_N_YEARS*N_TIME_STEP_PER_YEAR; i++)
		size_hiv_pos_progression[i] = DEFAULT_N_HIV_PROGRESS_PER_TIME_STEP;

	/* Initialise the number of people in each group to be zero (as no HIV at start of simulation): */
	for (i=0; i<MAX_N_YEARS*N_TIME_STEP_PER_YEAR; i++)
		n_cascade_events[i] = 0;

	/* Initialise the size of the arrays to the default: */
	for (i=0; i<MAX_N_YEARS*N_TIME_STEP_PER_YEAR; i++)
		size_cascade_events[i] = DEFAULT_N_HIV_PROGRESS_PER_TIME_STEP;


	/* Initialise the number of people in each group to be zero 
	 * (as no VMMC at start of simulation - note traditional MC is dealt with separately): */
	for (i=0; i<N_TIME_STEP_PER_YEAR; i++)
		n_vmmc_events[i] = 0;

	/* Initialise the size of the arrays to the default: */
	for (i=0; i<N_TIME_STEP_PER_YEAR; i++)
		size_vmmc_events[i] = DEFAULT_N_HIV_PROGRESS_PER_TIME_STEP;

	for (i=0; i<MAX_N_YEARS*N_TIME_STEP_PER_YEAR; i++)
		n_planned_breakups[i] = 0;

	for (i=0; i<MAX_N_YEARS*N_TIME_STEP_PER_YEAR; i++)
		size_planned_breakups[i] = MAX_BREAKUPS_PER_TIME_STEP;

	/* Set annual outputs string to be blank: */

	 memset(annual_outputs_string, '\0', sizeof(annual_outputs_string));
	 memset(phylogenetics_output_string, '\0', sizeof(phylogenetics_output_string));

}
	
void alloc_all_memory(parameters **allrunparameters, int n_runs, individual **individual_population, population **pop, population_size **n_population, stratified_population_size **n_population_stratified, age_list_struct **age_list, child_population_struct **child_population,
		partnership **partner_pairs, long **n_partnerships, individual ***susceptible_in_serodiscordant_partnership, long **n_susceptible_in_serodiscordant_partnership, population_partners **pop_available_partners, population_size **n_pop_available_partners,
		individual ****hiv_pos_progression, long **n_hiv_pos_progression, long **size_hiv_pos_progression, individual ****cascade_events, long **n_cascade_events, long **size_cascade_events, individual ****vmmc_events, long **n_vmmc_events, long **size_vmmc_events, 
		partnership ****planned_breakups, long **n_planned_breakups,long **size_planned_breakups,
		long **new_deaths, long **death_dummylist, long **new_partners_f_sorted, long **shuffled_idx, long **new_partners_f_non_matchable, long **new_partners_m, long **new_partners_m_sorted, long **partner_dummylist,
		population_size_one_year_age **n_infected, population_size_one_year_age **n_newly_infected, population_size **n_infected_wide_age_group, population_size **n_newly_infected_wide_age_group,
		chips_sample_struct **chips_sample, cumulative_outputs_struct **cumulative_outputs)
{

	long i;

	*allrunparameters = malloc(n_runs * sizeof(parameters));
	if(*allrunparameters==NULL)
	{
		printf("Unable to allocate allrunparameters in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*individual_population = malloc(MAX_POP_SIZE*sizeof(individual)); /* at this stage individual_population[i]->partner_pairs and partner_pairs_HIVpos point to random place where no space has been allocated for storing these partnership objects. This is done later on */
	if(*individual_population==NULL)
	{
		printf("Unable to allocate individual_population in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*pop = malloc(sizeof(population));
	if(*pop==NULL)
	{
		printf("Unable to allocate pop in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*n_population = malloc(sizeof(population_size));
	if(*n_population==NULL)
	{
		printf("Unable to allocate n_population in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*n_population_stratified = malloc(sizeof(stratified_population_size));
	if(*n_population_stratified==NULL)
	{
		printf("Unable to allocate n_population_stratified in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*n_infected = malloc(sizeof(population_size_one_year_age));
	if(*n_infected==NULL)
	{
		printf("Unable to allocate n_infected in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*n_newly_infected = malloc(sizeof(population_size_one_year_age));
	if(*n_newly_infected==NULL)
	{
		printf("Unable to allocate n_newly_infected in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*n_infected_wide_age_group = malloc(sizeof(population_size));
	if(*n_infected_wide_age_group==NULL)
	{
		printf("Unable to allocate n_infected_wide_age_group in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*n_newly_infected_wide_age_group = malloc(sizeof(population_size));
	if(*n_newly_infected_wide_age_group==NULL)
	{
		printf("Unable to allocate n_newly_infected_wide_age_group in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*age_list = malloc(sizeof(age_list_struct));
	if(*age_list==NULL)
	{
		printf("Unable to allocate age_list in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}
	
		
	*child_population = malloc(2*sizeof(child_population_struct)); /* The 2 is because we have HIV- and HIV+ lists. */
	if(*child_population==NULL)
	{
		printf("Unable to allocate child_population in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*new_deaths = malloc(MAX_N_PER_AGE_GROUP*sizeof(long)); /* There are <MAX_N_PER_AGE_GROUP people in an age group, so the number of people dying in that group has to be less than that number. */
	if(*new_deaths==NULL)
	{
		printf("Unable to allocate new_deaths in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*death_dummylist = malloc(MAX_N_PER_AGE_GROUP*sizeof(long)); /* This is just a dummy list of 0..MAX_N_PER_AGE_GROUP from which we pick the indices of people who will die in deaths_natural_causes() in demographics.c. This list of indices is stored in new_death[]. */
	if(*death_dummylist==NULL)
	{
		printf("Unable to allocate death_dummylist in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*new_partners_f_sorted = malloc(MAX_N_PER_AGE_GROUP*MAX_PARTNERSHIPS_PER_INDIVIDUAL*sizeof(long));
	if(*new_partners_f_sorted==NULL)
	{
		printf("Unable to allocate new_partners_f_sorted in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*shuffled_idx = malloc(MAX_N_PER_AGE_GROUP*MAX_PARTNERSHIPS_PER_INDIVIDUAL*sizeof(long));
	if(*shuffled_idx==NULL)
	{
		printf("Unable to allocate shuffled_idx in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*new_partners_f_non_matchable = malloc(MAX_N_PER_AGE_GROUP*MAX_PARTNERSHIPS_PER_INDIVIDUAL*sizeof(long));
	if(*new_partners_f_non_matchable==NULL)
	{
		printf("Unable to allocate new_partners_f_non_matchable in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*new_partners_m = malloc(MAX_N_PER_AGE_GROUP*MAX_PARTNERSHIPS_PER_INDIVIDUAL*sizeof(long));
	if(*new_partners_m==NULL)
	{
		printf("Unable to allocate new_partners_m in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*new_partners_m_sorted = malloc(MAX_N_PER_AGE_GROUP*MAX_PARTNERSHIPS_PER_INDIVIDUAL*sizeof(long));
	if(*new_partners_m_sorted==NULL)
	{
		printf("Unable to allocate new_partners_m_sorted in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*partner_dummylist = malloc(MAX_N_PER_AGE_GROUP*MAX_PARTNERSHIPS_PER_INDIVIDUAL*sizeof(long));
	if(*partner_dummylist==NULL)
	{
		printf("Unable to allocate partner_dummylist in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}


	// THIS IS ***FAR*** TOO SMALL: should be something like (Duration of simulation) / ((Average age at death-AGE_ADULT)/(average # of partners)) * (MAX_POP_SIZE/2)
	*partner_pairs = malloc(MAX_POP_SIZE*MAX_PARTNERSHIPS_PER_INDIVIDUAL*sizeof(partnership)); // MAYBE NEEDS SOMETHING BIGGER BECAUSE OF DYNAMICS OF PARTNERSHIPS
	if(*partner_pairs==NULL)
	{
		printf("Unable to allocate partner_pairs in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*n_partnerships = malloc(sizeof(long)); /* only need space for one long */
	if(*n_partnerships==NULL)
	{
		printf("Unable to allocate n_partnerships in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*susceptible_in_serodiscordant_partnership = malloc(MAX_POP_SIZE*MAX_PARTNERSHIPS_PER_INDIVIDUAL*sizeof(individual*));
	if(*susceptible_in_serodiscordant_partnership==NULL)
	{
		printf("Unable to allocate susceptible_in_serodiscordant_partnership in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*n_susceptible_in_serodiscordant_partnership = malloc(sizeof(long)); /* only need space for one long */
	if(*n_susceptible_in_serodiscordant_partnership==NULL)
	{
		printf("Unable to allocate n_susceptible_in_serodiscordant_partnership in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}


	*pop_available_partners = malloc(sizeof(population_partners)); // Here only storing adresses to individuals who already exist and have been allocated memory for so should be ok
	if(*pop_available_partners==NULL)
	{
		printf("Unable to allocate pop_available_partners in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	*n_pop_available_partners = malloc(sizeof(population_size)); // This is ok as population_size contains only objects allocated statically
	if(*n_pop_available_partners==NULL)
	{
		printf("Unable to allocate n_pop_available_partners in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}


	*hiv_pos_progression = malloc(MAX_N_YEARS*N_TIME_STEP_PER_YEAR*sizeof(individual**)); /* hiv_pos_progression[t] is a list of pointers to HIV+ individuals whose next progression event will happen at time step param->start_time_simul+t */
	if(*hiv_pos_progression==NULL)
	{
		printf("Unable to allocate hiv_pos_progression in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}
	for(i=0 ; i<MAX_N_YEARS*N_TIME_STEP_PER_YEAR ; i++){
		(*hiv_pos_progression)[i] = malloc(DEFAULT_N_HIV_PROGRESS_PER_TIME_STEP*sizeof(individual*));
		if((*hiv_pos_progression)[i]==NULL){
			printf("Unable to allocate hiv_pos_progression[i] in alloc_all_memory. Execution aborted.");
			fflush(stdout);
			exit(1);
		}
	}

	*n_hiv_pos_progression = malloc(MAX_N_YEARS*N_TIME_STEP_PER_YEAR*sizeof(long));
	if(*n_hiv_pos_progression==NULL)
	{
		printf("Unable to allocate n_hiv_pos_progression in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}
	
	*size_hiv_pos_progression = malloc(MAX_N_YEARS*N_TIME_STEP_PER_YEAR*sizeof(long));
	if(*size_hiv_pos_progression==NULL){
		printf("Unable to allocate size_hiv_pos_progression in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}


	/* These is the arrays that store the cascade events (HIV testing, starting/stopping ART): */
	*cascade_events = malloc(MAX_N_YEARS*N_TIME_STEP_PER_YEAR*sizeof(individual**)); /* cascade_events[t] is a list of pointers to individuals whose next cascade event will happen at time step param->start_time_simul+t */
	if(*cascade_events==NULL)
	{
		printf("Unable to allocate cascade_events in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}
	for(i=0 ; i<MAX_N_YEARS*N_TIME_STEP_PER_YEAR ; i++){
		(*cascade_events)[i] = malloc(DEFAULT_N_HIV_CASCADE_PER_TIME_STEP*sizeof(individual*));
		if((*cascade_events)[i]==NULL){
			printf("Unable to allocate cascade_events[i] in alloc_all_memory. Execution aborted.");
			fflush(stdout);
			exit(1);
		}
	}

	*n_cascade_events = malloc(MAX_N_YEARS*N_TIME_STEP_PER_YEAR*sizeof(long));
	if(*n_cascade_events==NULL)
	{
		printf("Unable to allocate n_cascade_events in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}
	
	*size_cascade_events = malloc(MAX_N_YEARS*N_TIME_STEP_PER_YEAR*sizeof(long));
	if(*size_cascade_events==NULL){
		printf("Unable to allocate size_cascade_events in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	//////
	/* This schedules VMMC events. Note that unlike previous (HIV progression and cascade) we assume that VMMC events (scheduling VMMC, healing period) all take <1 year (very conservative - could make a few weeks if memory issues). */
	*vmmc_events = malloc(N_TIME_STEP_PER_YEAR*sizeof(individual**)); /* vmmc_events[t] is a list of pointers to HIV+ individuals whose next progression event will happen at time step param->start_time_simul+t */
	if(*vmmc_events==NULL)
	{
		printf("Unable to allocate vmmc_events in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}
	for(i=0 ; i<N_TIME_STEP_PER_YEAR ; i++){
		(*vmmc_events)[i] = malloc(DEFAULT_N_HIV_PROGRESS_PER_TIME_STEP*sizeof(individual*));
		if((*vmmc_events)[i]==NULL){
				printf("Unable to allocate vmmc_events[i] in alloc_all_memory. Execution aborted.");
				fflush(stdout);
				exit(1);
			}
	}

	*n_vmmc_events = malloc(N_TIME_STEP_PER_YEAR*sizeof(long));
	if(*n_vmmc_events==NULL)
	{
		printf("Unable to allocate n_vmmc_events in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}
	
	*size_vmmc_events = malloc(N_TIME_STEP_PER_YEAR*sizeof(long));
	if(*size_vmmc_events==NULL){
		printf("Unable to allocate size_vmmc_events in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	
	*planned_breakups = malloc(MAX_N_YEARS*N_TIME_STEP_PER_YEAR*sizeof(partnership**)); /* planned_breakups[t] is a list of pointers to partnerships planned to break up at time step param->start_time_simul+t */
	if(*planned_breakups==NULL)
	{
		printf("Unable to allocate planned_breakups in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}
	for(i=0 ; i<MAX_N_YEARS*N_TIME_STEP_PER_YEAR ; i++)
	{
		(*planned_breakups)[i] = malloc(MAX_BREAKUPS_PER_TIME_STEP*sizeof(partnership*));
	}
	
	*n_planned_breakups = malloc(MAX_N_YEARS*N_TIME_STEP_PER_YEAR*sizeof(long));
		if(*n_planned_breakups==NULL)
		{
			printf("Unable to allocate n_planned_breakups in alloc_all_memory. Execution aborted.");
			fflush(stdout);
			exit(1);
		}


	*size_planned_breakups = malloc(MAX_N_YEARS*N_TIME_STEP_PER_YEAR*sizeof(long));
	if(*size_planned_breakups==NULL)
	{
		printf("Unable to allocate size_planned_breakups in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}

	

	*chips_sample = malloc(sizeof(chips_sample_struct));
	if(*chips_sample==NULL)
	{
		printf("Unable to allocate chips_sample in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}
	
	
	*cumulative_outputs  = malloc(sizeof(chips_sample_struct));
	if(*cumulative_outputs==NULL)
	{
		printf("Unable to allocate cumulative_outputs in alloc_all_memory. Execution aborted.");
		fflush(stdout);
		exit(1);
	}
}

void free_all_memory(parameters *param, individual *individual_population, population *pop, population_size *n_population, stratified_population_size *n_population_stratified, age_list_struct *age_list, child_population_struct *child_population,
		partnership *partner_pairs, long *n_partnerships, individual **susceptible_in_serodiscordant_partnership, long *n_susceptible_in_serodiscordant_partnership, population_partners* pop_available_partners, population_size *n_pop_available_partners,
		individual ***hiv_pos_progression, long *n_hiv_pos_progression, long *size_hiv_pos_progression, individual ***cascade_events, long *n_cascade_events, long *size_cascade_events, individual ***vmmc_events, long *n_vmmc_events, long *size_vmmc_events, 
		partnership ***planned_breakups, long *n_planned_breakups, long *size_planned_breakups,
		long *new_deaths, long *death_dummylist, long *new_partners_f_sorted, long *shuffled_idx, long *new_partners_f_non_matchable, long *new_partners_m, long *new_partners_m_sorted, long *partner_dummylist,
		population_size_one_year_age *n_infected, population_size_one_year_age *n_newly_infected, population_size *n_infected_wide_age_group, population_size *n_newly_infected_wide_age_group,
		chips_sample_struct *chips_sample, cumulative_outputs_struct *cumulative_outputs)
{

	long i;

	free(param);
	free(individual_population);
	free(pop);
	free(n_population);
	free(n_population_stratified);

	free(n_infected);
	free(n_newly_infected);

	free(n_infected_wide_age_group);
	free(n_newly_infected_wide_age_group);

	free(age_list);
	free(child_population);

	free(new_deaths);
	free(death_dummylist);

	free(new_partners_f_sorted);
	free(shuffled_idx);
	free(new_partners_f_non_matchable);
	free(new_partners_m);
	free(new_partners_m_sorted);
	free(partner_dummylist);

	free(partner_pairs);
	free(n_partnerships);

	free(susceptible_in_serodiscordant_partnership);
	free(n_susceptible_in_serodiscordant_partnership);

	free(pop_available_partners);
	free(n_pop_available_partners);

	/* Note we free each element within hiv_pos_progression in the function carry_out_HIV_events_per_timestep() in hiv.c. */
	for(i=0 ;i<MAX_N_YEARS*N_TIME_STEP_PER_YEAR ;i++)
		free(hiv_pos_progression[i]);
	free(hiv_pos_progression);
	free(n_hiv_pos_progression);
	free(size_hiv_pos_progression);

	/* Note we free each element within cascade_events in the function carry_out_cascade_events_per_timestep() in hiv.c. */
	for(i=0 ;i<MAX_N_YEARS*N_TIME_STEP_PER_YEAR ;i++)
		free(cascade_events[i]);
	free(cascade_events);
	free(n_cascade_events);
	free(size_cascade_events);
	

	/* Didn't free vmmc events so free them here: */
	for(i=0; i<N_TIME_STEP_PER_YEAR; i++){
		free(vmmc_events[i]);
	}
	free(vmmc_events);
	free(n_vmmc_events);
	free(size_vmmc_events);

	
	for(i=0 ; i<MAX_N_YEARS*N_TIME_STEP_PER_YEAR ; i++)
	{
		free(planned_breakups[i]);
	}
	free(planned_breakups);

	free(n_planned_breakups);
	free(size_planned_breakups);

	free(chips_sample);
	free(cumulative_outputs);
}
