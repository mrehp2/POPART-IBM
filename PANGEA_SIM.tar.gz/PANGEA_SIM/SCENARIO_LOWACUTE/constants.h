/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef CONSTANTS_H_
#define CONSTANTS_H_


/* Defines fixed constants and creates fixed-size global arrays for use throughout the code. */
/************************************************************************/
/******************************* Includes  ******************************/
/************************************************************************/

/* Standard libraries */
#include <stdio.h>      /* printf, scanf, NULL */
#include <stdlib.h>     /* calloc, exit, free */

#include <math.h>
#include <time.h>
#include <string.h>

/* GSL libraries */
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>

/************************************************************************/
/******************* For Debugging - remove eventually ******************/
/************************************************************************/
#define PRINT_DEBUG_DEMOGRAPHICS 0
#define PRINT_DEBUG_INPUT 0
#define PRINT_PHYLOGENETICS_OUTPUT 1 /* if 1 print phylo output to file, otherwise do not print */
#define CHECKMODE 0 // if 0 then normal simulation is run, otherwise check functions are run
#define FOLLOW_INDIVIDUAL -1 // if -1 then normal run, otherwise printing things and checking everything that happens to an individual with a certain ID

/************************************************************************/
/************************** Random number variables *********************/
/************************************************************************/

const gsl_rng_type * TYPE_RNG;
gsl_rng * rng;

/************************************************************************/
/***************************** General variables ************************/
/************************************************************************/
#define FALSE 0
#define TRUE 1

/************************************************************************/
/***************************** Time variables ***************************/
/************************************************************************/
/* time step is 1/4th of a month (approximately a week) */
#define N_TIME_STEP_PER_YEAR 48 /* This is the number of time steps in 1 year. */
#define TIME_STEP 1.0/N_TIME_STEP_PER_YEAR

//extern int MAX_N_YEARS;

#define MAX_N_YEARS 80 /* Maximum number of years the simulation will run for */


/************************************************************************/
/***************************** Settings ***************************/
/************************************************************************/
/* Labels for countries (or clusters): */
#define ZAMBIA 1
#define SOUTH_AFRICA 2
/* First 12 clusters in M&E reports are always Zambia, so cluster numbers 1-12 for Zambia and >12 for South Africa: */
#define IS_ZAMBIA 12

/* Trial arm: 0=ARM C, 1=ARM A, 2=ARM B. */
#define ARM_A 1
#define ARM_B 2
#define ARM_C 0

/************************************************************************/
/***************************** Demographics ***************************/
/************************************************************************/

#define MAX_POP_SIZE 600000 /* the maximum population size for memory allocation */
#define MAX_N_PER_AGE_GROUP MAX_POP_SIZE/2   /* This is the maximum number of people in each adult age year group (ie 13, 14, 15...). The denominator is chosen to be really conservative (each age year will be <<5% of adult population)- as this is used for static memory allocation. It is also the maximum number of people who can die in each age group in a given timestep. */

//// BE CAREFUL, MAY NEED TO BE UPDATED IF VERY LONG PROJECTIONS ////
#define AGE_ADULT 13 /* age at which individuals enter the simulation */
#define N_AGE 7 /* number of age groups */

extern const int AGE_GROUPS[N_AGE]; /* lower bounds of the age groups considered for partnership formation */
extern const int AGE_GROUPS_WITH_OLD[N_AGE+1]; /* lower bounds of the age groups considered for partnership formation */

#define MAX_AGE 80                  /* Upper bound for age at start of simulation. */

extern const int FIND_AGE_GROUPS[MAX_AGE-AGE_ADULT]; /* Convert from (age-AGE_ADULT) to the AGE_GROUPS index. Each entry in the array is an AGE_GROUPS index. */

#define N_GENDER 2 /* Number of genders. */

#define MALE 0
#define FEMALE 1

#define DEAD -2 /* used as CD4 value to identify that people are dead */

#define NSTEPS_GESTATION_TIME 36     /* This is timestep dependent (currently 36 timesteps = 9 months). */

extern long id_counter;                  /* This will assign a unique id to each person. */

extern int TRIAL_ARM;

extern long DEBUG_NHIVPOS;
extern long DEBUG_NHIVPOSLASTYR;
extern long DEBUG_NHIVDEAD;
extern long PANGEA_N_ANNUALACUTEINFECTIONS;
extern long PANGEA_N_ANNUALINFECTIONS;

/************************************************************************/
/***************************** Partnership ***************************/
/************************************************************************/

#define MAX_PARTNERSHIPS_PER_INDIVIDUAL 10 /* An individual can belong to up to MAX_PARTNERSHIPS_PER_INDIVIDUAL partnerships at any time point. */

#define MAX_BREAKUPS_PER_TIME_STEP MAX_PARTNERSHIPS_PER_INDIVIDUAL*MAX_POP_SIZE/2000 /* This is the maximum number of breakups that can happen in a given time step. Taken to be VERY conservative */

#define N_RISK 3


/* codes for sex riskiness of an individual. Note if we change these, then need to change RISK_GP_NAMES (defined in constants.c). */
#define LOW 0
#define MEDIUM 1
#define HIGH 2
extern const char RISK_GP_NAMES[N_RISK][5];

/************************************************************************/
/***************************** HIV related ***************************/
/************************************************************************/

/* codes for HIV status */
#define UNINFECTED 0
#define ACUTE 1
#define CHRONIC 2



/* codes for indiv->ART_status - could merge with HIV status? Note that these are states and not processes. */
#define ARTNEG  -1 // If never tested HIV positive (note that this is tested, not serostatus).
#define ARTNAIVE 0 // Never been on ART.
#define EARLYART 1 // First few weeks/months before achieve viral suppression. Higher mortality and drop-out rate.
#define LTART_VS 2 // longer-term ART and Virally Suppressed (so low transmission, no CD4 progression or drug resistance).  
#define LTART_VU 3 // longer-term ART and Virally Unsuppressed (so higher transmission, could have (but not currently) CD4 progression and drug resistance).
#define ARTDROPOUT 4 // Has been on ART before but not currently.
#define CASCADEDROPOUT 5 // Dropped out of HIV care cascade prior to ever starting ART.
#define ARTDEATH 6 // Signals that the person needs to be removed as they die while on ART. 

/* Used as CD4 value to identify that people are not infected with HIV.
 * Note: CD4==-2 means the person is dead.
 * 0="CD4>500", 1="CD4 350-500", 2="CD4 200-350", 3="CD4 <200". */
#define CD4_UNINFECTED -1 

/* 4 set-point viral load categories (0="<4"; 1="4-4.5"; 2="4.5-5"; 3=">5") */
#define NSPVL 4
/* 4 CD4 categories (0=">500", 1="350-500", 2= "200-350", 3="<200") */
#define NCD4 4

/* HIV progression events: */
#define NHIVEVENTS 4
#define HIVEVENT_ENDOFACUTE 0
#define HIVEVENT_CD4_PROGRESSION 1
#define HIVEVENT_STARTART_LOWCD4 2
#define HIVEVENT_AIDSDEATH 3
#define NOEVENT -1

//#define HIVEVENT_TEST 5 // Note include tests for HIV-
//#define HIVEVENT_CD4TEST 6
//#define HIVEVENT_CD4GETRESULTS 7
//#define HIVEVENT_STARTART 7
//#define HIVEVENT_ARTANDVLSUPPRESSED 8 // This will be something like 6 months to 1 year after starting ART. At this point the person will have reduced risk of HIV-related mortality and fully reduced infectivity.
//#define HIVEVENT_STOPART 9            // May depend on CD4 (and VL?)
//#define HIVEVENT_RESTARTART 10        // This will be dependent on CD4 (and R-SPVL?)
 
/* HIV test/treatment cascade events indiv->next_cascade_event
 * Note that these are processes (in particular CD4 test), not states: */
/* Decides if a cascade event (e.g. an HIV test) is from PopART or not. 
 * If it is PopART then things happen faster (e.g. time to CD4 test is quicker), and
 * ART CD4 eligibility may be different. */
#define NOTPOPART 0
#define POPART 1

/* Note that these two numbers need to change if we add any states to the cascade: */
#define NCASCADEEVENTS_NONPOPART 7      /* We test if (EVENT<NCASCADEEVENTS_NONPOPART) to determine if the event is due to popart (=1) or not (=0). */
#define NCASCADEEVENTS 14

#define CASCADEEVENT_HIV_TEST_NONPOPART 0
#define CASCADEEVENT_CD4_TEST_NONPOPART 1
#define CASCADEEVENT_START_ART_NONPOPART 2
#define CASCADEEVENT_VS_NONPOPART 3
#define CASCADEEVENT_VU_NONPOPART 4
#define CASCADEEVENT_DROPOUT_NONPOPART 5
#define CASCADEEVENT_ARTDEATH_NONPOPART 6
#define CASCADEEVENT_HIV_TEST_POPART 7
#define CASCADEEVENT_CD4_TEST_POPART 8
#define CASCADEEVENT_START_ART_POPART 9
#define CASCADEEVENT_VS_POPART 10
#define CASCADEEVENT_VU_POPART 11
#define CASCADEEVENT_DROPOUT_POPART 12
#define CASCADEEVENT_ARTDEATH_POPART 13

#define NEVERHIVTESTED -1

/* Sensitivity and specificity of HIV tests. By default assume 1, but could potentially change these to be lower, or even time-varying. */
#define HIVTESTSENSITIVITY 1
#define HIVTESTSPECIFICITY 1


/* Circumcision states for indiv->circ: */
#define UNCIRC 0
#define UNCIRC_WAITING_VMMC 1
#define VMMC 2
#define VMMC_HEALING 3
#define TRADITIONAL_MC 4




#define DEFAULT_N_HIV_PROGRESS_PER_TIME_STEP MAX_POP_SIZE/100   /* This is the default number of HIV+ people whose next progression event will happen in a given time step. 
															   Taken to be moderately conservative - in a 50% prevalence population assume average of 1 HIV event per year. 
															   	At some point in the future we will tune this to avoid too many reallocs(). */
#define DEFAULT_N_HIV_CASCADE_PER_TIME_STEP MAX_POP_SIZE/50   /* This is the default number of people who will have an HIV cascade event (HIV test, start ART etc) in a given time step. 
															   Taken to be moderately conservative - in a 50% prevalence population assume average of 1 HIV event per year. 
															   	At some point in the future we will tune this to avoid too many reallocs(). */

#define RESIZEMEM 100          /* If we run out of memory in DEFAULT_N_HIV_PROGRESS_PER_TIME_STEP, add this much extra. Note that the value is arbitrary so can change to optimise. */ 
#define RESIZEMEM_BREAKUP 100   /* If we run out of memory in planned_breakups[] array, add this much extra. Note that the value is arbitrary so can change to optimise. */

/* This is an array used by hiv_acquisition() to store the per-partnership hazard from all HIV+ partners of an individual. */
double PER_PARTNERSHIP_HAZARD_TEMPSTORE[MAX_PARTNERSHIPS_PER_INDIVIDUAL];


/* This stores the prevalence, prevalence by gender and age group, incidence, number of HIV tests ever done, number of CD4 tests ever done, number on ART, number on ART and HIV+ etc. */
char annual_outputs_string[1000000];

/* This stores the output we need for phylogenetics so that it is printed at the end of the simulation. 
 * It will contain the ID of infectee, infector, whether the infector was in acute infection etc. */
/* Estimate that each line in phylogenetics_output_string contains roughly 30 characters, and that we may have up to 
 * 50,000 transmission events per simulation. */
/////// MEMORY CHECK THIS.
char phylogenetics_output_string[3000000];

#define PHYLO_SCENARIO 0 /* used if we want to run several scenarios for PANGEA */




/************************************************************************/
/* Define macros (bits of code that we always use).
 * Note - I found http://www.cprogramming.com/tutorial/cpreprocessor.html helpful to understand this! */
 /************************************************************************/

//#define AGE_INDEX(DoB,start_simul) ( (int) floor(DoB - start_simul) - (AGE_ADULT)) - youngest_age_group_index



#endif
