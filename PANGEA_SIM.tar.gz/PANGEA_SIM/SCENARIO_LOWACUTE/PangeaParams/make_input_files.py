#  This file is part of the PopART IBM.

#    The PopART IBM is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    The PopART IBM is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.

import re   # Regular expression library in python.
import os,sys,random


# Set random seed - either pass as argument or use default value:
if len(sys.argv)>1:
    ran_seed = int(sys.argv[1])
else:
    ran_seed = 1 # Default value.

random.seed(ran_seed)

nsample = 10
filename_list = ["init_param.txt","param_demographics.txt","param_times.txt","param_HIV.txt","param_cascade.txt","param_partnerships.txt"]




# Not used at present: 
# Function which checks what s is - is it a number (if so return that number as a string), or the words LHC (in which case return "LHC"). Otherwise assume it is the name of the parameter and return "ParamName"
# def matchregexp(s):

#     # We use python regular expressions to get what (I hope) is an exhaustive list of every way we might write a number. There are two types of patterns we consider:
#     # the first kind of pattern is as follows:
#     # a digit between 1-9 ([1-9]), then 0 or more digits between 0 and 9 ([0-9]*), then either a . or nothing (\.?), then a whitespace character.
#     pattern = re.compile("[1-9][0-9]*\.?[0-9]*\s",flags=0)
#     # Second pattern is either a 0 or nothing (0?), then a . (\.), then 0 or more digits ([0-9]*), then a whitespace character (\s)
#     pattern2 = re.compile("0?\.[0-9]*\s",flags=0)

    
#     # We also check if it is "LHC". We allow any combination of upper and lowercase L,H,C to signal if this is to be a latin hypercube sample.
#     lhcpattern = re.compile("[Ll][Hh][Cc]\s",flags=0)

    
#     scenariopattern = re.compile("[Ss][Cc][Ee][Nn][Aa][Rr][Ii][Oo]\s",flags=0)

#     # Now do the checking:
#     if (pattern.match(s) or pattern2.match(s)):
#         return s
#     elif (lhcpattern.match(s)):
#         return "LHC"
#     elif (scenariopattern.match(s)):
#         return "SCENARIO"
#     else:
#         # In this case it should be a parameter name:
#         print "s=",s
#         return "ParamName"
        




# This function takes a string variable (which will be a sinlge line from a parameter file) and formats it as needed:
def parse_line(line):

    # This will store the line output (with placeholders for variables which need LHC or grid sampling):
    line_output = ""

    # This will store the min+max of the variables which need lhc sampling. The order which they turn up in the source file is preserved so that when we latin hypercube sample them it is easy to replace the correct variable with the corresponding placeholder in line_output.
    lhc_sampling_vars = []

    # This will store all the scenarios - if we have a variable which we want to take the values 1,2,3 for example then the line in the param file will be "this_param_name SCENARIO 1 2 3". 
    scenario_vars =[]


    # Anything after a double slash is treated as a comment (ie C-like behaviour):
    line = line.split("//")[0].rstrip()

    # Remove any trailing whitespace at the end of the line:
    line = line.rstrip()
    # Replace commas by spaces (only needed if a csv file)
    line = line.replace(","," ")
    # Replace tabs by spaces 
    line = line.replace("\t"," ")
    while (line.find("  ")>-1):
        line = line.replace("  "," ")

    # split the line by spaces:
    words = line.split(" ")
    # Remove trailing and leading whitespace (e.g. tabs) from each word:
    words = [w.rstrip() for w in words]
    words = [w.lstrip() for w in words]


    # Now check if this is a Latin hypercube sampled variable - this will be indicated by "LHC" in the second column followed by 2 numbers which are the min+max values of the variable to be sampled.
    # At present we are assuming uniform dists on each var - can change fairly easily.
    
    if (words[1].upper()=="LHC"):
        if len(words)==4:
            # We store the min and max for each variable 
            lhc_sampling_vars += [float(words[2]),float(words[3])]
            # Add a placeholder in line_output so easy to replace later on:
            line_output += "LHC "
        else:
            # Catch errors:
            print "ERROR: Lines with LHC in them should have 4 entries: var_name LHC MinVal MaxVal\n"
            sys.exit(1)
    elif (words[1].upper()=="SCENARIO" or words[1].upper()=="SCENARIOS"): # Use upper to ensure that using upper case.
        # Store all the scenarios (which are all the things in the line after the word "SCENARIO":
        scenario_vars +=words[2:]
        line_output += "SCENARIO "
    else:
        for w in words[1:]:
            # At this point only first column can be non-decimal.
            if (w=="ParamName"):
                print "Not sure what went wrong - non-decimal in >1 column of param file. Exiting\n",w
                exit(1)
            else:
                line_output += w+" "
    return [line_output,lhc_sampling_vars,scenario_vars]


# Makes a list for each sampled variable of the values to take and the associated stepsizes:
# Function can be used for grid or Latin hypercube sampling:
def make_sampleframe(varlist,nsample):
    thissampleframe = []
    stored_stepsizes = []
    for v in varlist:
        # Assume for each variable that we have the [min,max]:
        minv = min(v)
        maxv = max(v)
        if (not(minv==v[0]) or not(maxv==v[1])):
            print "ERROR:varlist in wrong form. Exiting\n."
            sys.exit(1)
        # Use float to make sure that do NOT use integer division. The -1 ensures that the biggest value in the LHC is maxv
        stepsize = float(maxv - minv)/(nsample-1)

        # Store the stepsize (so we can use it in make_lhc)
        stored_stepsizes += [stepsize]

        # Generate a set of nsample points from minv to maxv equally spaced:
        # Note thissampleframe is a list of lists (each sublist is nsample points for a given variable v (in the same order as varlist).
        thissampleframe += [[minv + x*stepsize for x in range(0,nsample)]]
    return [thissampleframe,stored_stepsizes]



# This creates a grid sample (instead of LHC). Function not called at present - and has not been debugged.
# def make_grid(grid_sampleframe,nsample):
#     nvars = len(varsample_list)
#     # Check grid is not too big to run properly!
#     if (nvars*nsample)>1e6:
#         print "ERROR: Trying to make a grid from too many variables! Exiting\n"
#         sys.exit(1)
#     if nvars==0:
#         return -1
#     grid = []
#     for i in range(nsample):
#         coord = [] # This will store the "coordinates" of a single point in the grid - ie the value of each variable.
#         for j in range(nvars):
#             coord += [grid_sampleframe[j]]
#         grid.append(coord)
#     # Each element of the list "grid" is a point in the grid (ie a single sample of params)
#     return grid

    

def make_lhc(lhc_sampleframe,lhc_stepsize,nsample):
    nvars = len(lhc_sampleframe)
    if nvars==0:
        return -1
    lhc = []
    for i in range(nsample):
        coord = [] # This will store the "coordinates" of a single point in the LHC sample - ie the value of each variable within that sample.
        for j in range(nvars):
            temp = random.choice(lhc_sampleframe[j])
            coord += [temp]
            # This ensures we choose each point without replacement - ie generate a LHC:
            lhc_sampleframe[j].remove(temp)
        lhc.append(coord)
    # Each element of lhc is a point in the latin hypercube (ie a single sample of params)
    return lhc



# Here we want to merge the lhc and text output. text_output is a single string we will repeat nsample times, coming from a single param file. 
#In each copy we use a different element of lhc (ie a different set of LHC coordinates) to replace the "LHC" placeholders within text_output.
# This creates nsample different parameter sets, where most parameters are kept constant apart from the LHC ones.
# Note that if there are no LHC variables in this file then the output will be nsample copies of the same line.
def merge_lhc_and_text(lhc,text_output,i_lhc_min,i_lhc_max):
    

    # If there are no LHC variables then just return the original string
    if lhc==-1:
        return text_output + "\n"

    
    n_lhc = len(lhc)

    outstring = ""
    for i in range(n_lhc):
        length_lhc_sample = i_lhc_max - i_lhc_min
        if length_lhc_sample!=text_output.count("LHC"):
            print "Number of LHC's do not match number of coords in LHC. Exiting\n",lhc[i],text_output
            sys.exit(1)
        # make a copy of text_output where we can make local replacements:
        text_output_copy = text_output
        for j in range(i_lhc_min,i_lhc_max):
            text_output_copy = text_output_copy.replace("LHC",str(lhc[i][j]),1)
        outstring += text_output_copy + "\n"

    return outstring


def add_scenarios(scenario_vars,dict_outstring,cumulative_n_vars_with_scenarios_per_file,filename_list):
    # Check we don't have too many scenarios:
    n_scenarios = 1
    for s in scenario_vars:
        n_scenarios = n_scenarios * len(s)
    if (n_scenarios*nsample)>10000:
        print "Too many scenarios/too big latin hypercube sample). Exiting\n"
        exit(1)
    
    for s in scenario_vars:
        DONE_SCENARIO = 0
        for f in filename_list:
            # Check if there is at least one instance of the word SCENARIO, and we have not already carried out the scenario:
            if (dict_outstring[f].count("SCENARIO")>0 and DONE_SCENARIO==0):
                DONE_SCENARIO = 1
                temp_file_output = ""
                dict_outstring_temp_splitbyline = dict_outstring[f].rstrip().split("\n")
                for scenario in s:
                    for line in dict_outstring_temp_splitbyline:
                        # Make a copy of dict_outstring_temp_splitbyline where the first instance of the word SCENARIO is replaced, and add this to temp_file_output
                        temp_file_output = temp_file_output + line.replace("SCENARIO",scenario,1) + "\n"
                dict_outstring[f] = temp_file_output
            else:
                dict_outstring_temp = ""
                # We copy the line(s) in dict_outstring len(
                for scenario in s:
                    dict_outstring_temp += dict_outstring[f]

                dict_outstring[f] = dict_outstring_temp
                    
                
                
        


# Function ensures that we are always working in the correct directory (at present Zambia) based on how main.c calls this python script.
def sort_working_directory():

    # Check what the current working directory is. The .split("/")[-1] splits the directory path and takes the last bit (ie the name of the current subdirectory.

    # __file__ is the name of the script we are using including the path from the current directory to wherever the script is. os.path.basename(__file__) just gives the filename. By comparing them we can see if we are in the current directory of this script or not.
    if not(__file__==os.path.basename(__file__)):
        # This removes the filename from the path+filename, just leaving the path.
        dir = __file__.replace(os.path.basename(__file__),"")
        # Change the directory that python is working in:
        os.chdir(dir)


########################################################################################################
##########################################  Main code ##################################################
########################################################################################################




# Each element of this list is itself a list (array) containing the values of one variable ie [x_min, x_min+stepsize, x_min+2*stepsize...x_max] where stepsize = (x_max-x_min)/nsample.
lhc_sampling_vars_all = []
# This list will count the number of variables to be sampled using LHC per file. Note that it is a list (not a dictionary) but we use the same ordering as the list filename_list.
cumulative_n_lhc_vars_per_file = [0]
cumulative_n_lhc_vars = 0
# Now the same for the scenarios:
cumulative_n_vars_with_scenarios_per_file = [0]
cumulative_n_vars_with_scenarios = 0

# 
temp_store_output = {}

# This will store the scenarios we need for each variable (for some variables v we may want to run the code with e.g. v=2, v=5, v=10. This will allow us to run multiple scenarios (ie duplicate all non-scenario variables for each combination of scenario variables). Note that the total number of scenarios cannot be too big (otherwise slow to run IBM!)
scenario_vars = []


# Ensure we are in the correct directory:
sort_working_directory()

# Here we go through each input file in turn:
for f_i in range(len(filename_list)):
    f = filename_list[f_i]
    infile = open(f,"r")
    # Read in the file (this is read in initially as a single string including line breaks), then strip off the last line break, then split the remaining text by line break into a list called text_list. Each line of the original file is then an element in the list at this point.
    text_list = infile.read().rstrip().split("\n")
    infile.close()


    # Each element temp_store_output[f] stores the string output from that param file. Variables which are to be sampled have a placeholder (e.g. "LHC") put in the string instead of a value.
    temp_store_output[f] = ""


    # This for loop goes through each element of the list (ie line takes the values text_list[0], text_list[1], etc.
    for line in text_list:
        if line!="":
            [line_output,line_lhc_sampling_vars,line_scenario_vars] = parse_line(line)
            temp_store_output[f] += line_output
            # This is a python way of checking if a list is non-empty:
            if line_lhc_sampling_vars:
                lhc_sampling_vars_all += [line_lhc_sampling_vars]
                cumulative_n_lhc_vars = cumulative_n_lhc_vars + 1
            if line_scenario_vars:
                scenario_vars += [line_scenario_vars]
                cumulative_n_vars_with_scenarios = cumulative_n_vars_with_scenarios + 1
    cumulative_n_lhc_vars_per_file += [cumulative_n_lhc_vars]
    cumulative_n_vars_with_scenarios_per_file += [cumulative_n_vars_with_scenarios]



[lhc_sampleframe,lhc_stepsize] = make_sampleframe(lhc_sampling_vars_all,nsample)
lhc = make_lhc(lhc_sampleframe,lhc_stepsize,nsample)





# dict_outstring is a dictionary which saves the output string for each file.
dict_outstring = {}
for f_i in range(len(filename_list)):
    f = filename_list[f_i]

    # Note that I've set up cumulative_n_lhc_vars_per_file[] so that the f_i to f_i+1 th elements are the number of latin hypercube vars for that given variable.
    dict_outstring[f] = merge_lhc_and_text(lhc,temp_store_output[f],cumulative_n_lhc_vars_per_file[f_i],cumulative_n_lhc_vars_per_file[f_i+1]) 



add_scenarios(scenario_vars,dict_outstring,cumulative_n_vars_with_scenarios_per_file,filename_list)

for f in filename_list:
#for f_i in range(len(filename_list)):
#    f = filename_list[f_i]
    outfilename = f.replace("param","param_processed")
    outfile = open(outfilename,"w")
    outfile.write(dict_outstring[f])
    outfile.close()

print "INPUT_FILES_DONE"
