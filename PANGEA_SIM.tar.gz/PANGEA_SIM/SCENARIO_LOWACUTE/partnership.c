/*  This file is part of the PopART IBM.

    The PopART IBM is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    The PopART IBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with the PopART IBM.  If not, see <http://www.gnu.org/licenses/>.
 */


/* This file includes:
 * Partnership formation
 * Partnership dissolution
 */


/************************************************************************/
/******************************* Includes  ******************************/
/************************************************************************/

#include "partnership.h"
#include "utilities.h"
#include "output.h"

/************************************************************************/
/******************************** functions *****************************/
/************************************************************************/

/* Function does: fill in pair as a partnership between ind1 and ind2 formed at t_form_partnership
 * 					adds the pair to planned_breakups and n_planned_breakups
 * 					updates susceptible_in_serodiscordant_partnership and n_susceptible_in_serodiscordant_partnership accordingly
 * 					NOTE THAT UPDATE OF available_partners and n_available_partners is done outside of this function, afterwards
 * 					(because several partnerships are planned in advance based on the index of individuals in the list available_partnership,
 * 					it messes things up if we update the list after each partnership formation so we do it once they are all formed)
 * function arguments: pointer to the pair and the 2 individuals, time of partnership formation, list of planned_breakups and n_planned_breakups, list of susceptible_in_serodiscordant_partnership and n_susceptible_in_serodiscordant_partnership, poiter to parameters.
 * Function returns: nothing */
void new_partnership(partnership *pair, individual* ind1, individual* ind2, int t_form_partnership, 
		partnership*** planned_breakups, long *n_planned_breakups, long *size_planned_breakups, 
		individual** susceptible_in_serodiscordant_partnership, long *n_susceptible_in_serodiscordant_partnership, 
		parameters *param){
	/////// before calling this function one needs to check whether it is possible to form such a partnership
	/////// ie if ind1 and ind2 have some "free" partnerships,
	/////// are indeed of opposite sex,
	/////// and are not already in a partnership with each other!

	int g;

	/// FOR DEBUGGING, checking that these individuals are not dead!
	if(ind1->cd4==DEAD || ind2->cd4==DEAD)
	{
		printf("Problem: trying to make partnership with dead person...\n");
		if (ind1->cd4==DEAD)
			printf("Dead person ID = %li, other person = %li\n",ind1->id,ind2->id);
		else
			printf("Dead person ID = %li, other person = %li\n",ind2->id,ind1->id);
		fflush(stdout);
		//exit(1);
	}

	//printf("Partnership formation involving individuals %ld and %ld\n",ind1->id,ind2->id);
	if(ind1->id==FOLLOW_INDIVIDUAL || ind2->id==FOLLOW_INDIVIDUAL)
	{
		printf("Partnership formation involving individuals %ld and %ld\n",ind1->id,ind2->id);
		fflush(stdout);
	}

	/* filling in a new partnership which points to the two individuals ind1 and ind2 and drawing a partnership duration */
	pair->ptr[ind1->gender] = ind1;
	pair->ptr[ind2->gender] = ind2;
	/* duration (in number of time steps) of the partnership */
	pair->duration_in_time_steps = time_to_partnership_dissolution(param,ind1->sex_risk,ind2->sex_risk); //// IF WE WANT SOMETHING ASYMETRICAL ACCORDING TO GENDER WILL NEED TO SPECIFY WHICH IS THE MALE AND WHICH IS THE FEMALE

	// This is for debug to check that all partnerships are broken up at some point
	/*if(t_form_partnership + pair->t_dissolve*TIME_STEP>param->end_time_simul)
	{
		printf("We will not see this partnership breakup (breakup planned for %g).\n",t_form_partnership + pair->t_dissolve*TIME_STEP);
		fflush(stdout);
		getchar();
	}*/

	/* updating the partners of ind1 and ind2 accordingly */
	ind1->n_partners ++;
	ind1->partner_pairs[ind1->n_partners-1] = pair;
	if(ind2->HIV_status>0 && ind1->HIV_status==0) /* then we need to tell ind1 that he has a new HIV partner */
	{
		ind1->n_HIVpos_partners ++;
		ind1->partner_pairs_HIVpos[ind1->n_HIVpos_partners-1] = pair;
	}
	ind1->n_lifetime_partners++;

	ind2->n_partners ++;
	ind2->partner_pairs[ind2->n_partners-1] = pair;
	if(ind1->HIV_status>0 && ind2->HIV_status==0)  /* then we need to tell ind2 that he has a new HIV partner */
	{
		ind2->n_HIVpos_partners ++;
		ind2->partner_pairs_HIVpos[ind2->n_HIVpos_partners-1] = pair;
	}
	ind2->n_lifetime_partners++;
	
	/* adding this partnership to planned_breakups and n_planned_breakups */
	int time_breakup = N_TIME_STEP_PER_YEAR*(t_form_partnership- param->start_time_simul) + pair->duration_in_time_steps ;
	if(time_breakup<MAX_N_YEARS*N_TIME_STEP_PER_YEAR)
	{
		
		/* Check if we've run out of memory: */
		if (n_planned_breakups[time_breakup]>=(size_planned_breakups[time_breakup])){
			size_planned_breakups[time_breakup] = size_planned_breakups[time_breakup] + RESIZEMEM_BREAKUP;
			printf("Reallocating stuff for planned_breakups[] now\n");
			fflush(stdout);
			planned_breakups[time_breakup] = realloc(planned_breakups[time_breakup],size_planned_breakups[time_breakup]*sizeof(partnership*));
			if (planned_breakups[time_breakup] == NULL){
				printf("Unable to re-allocate planned_breakups[i]. Execution aborted.");
				fflush(stdout);
				exit(1);
			}
		}	
		
		planned_breakups[time_breakup][n_planned_breakups[time_breakup]] = pair;
		n_planned_breakups[time_breakup]++;
	}

	/* if the partnership is serodiscordant and the HIV- is not yet in the list of susceptible_in_serodiscordant_partnership, 
	 * adding the HIV- partner to susceptible_in_serodiscordant_partnership and n_susceptible_in_serodiscordant_partnership */
	if(is_serodiscordant(pair))
	{
		for(g=0 ; g<N_GENDER ; g++)
		{
			if(pair->ptr[g]->HIV_status==0) /* this is the susceptible individual in the serodiscordant partnership which is formed */
			{
				if(pair->ptr[g]->idx_serodiscordant==-1) /* this means this individual is not yet in the list susceptible_in_serodiscordant_partnership*/
				{
					/* then add the susceptible from susceptible_in_serodiscordant_partnership and n_susceptible_in_serodiscordant_partnership */
					add_susceptible_to_list_serodiscordant_partnership(pair->ptr[g], susceptible_in_serodiscordant_partnership,  n_susceptible_in_serodiscordant_partnership);
				}
			}
		}
	}
}

/* Function does: randomly draws a time to partnership dissolution as function of risk group of two partners
 * function arguments: two integers representing two risk groups of partners
 * Function returns: the number of time steps after which partnership will be dissolved
 * NOTE: currently no matter what the risk group of partners is, the duration of partnerships is set to a random number
 * drawn from a unique Exp distribution with mean 10 years, discretized so that it is exactly a multiple of time steps
 * the number returned is the number of time steps from formation to dissolution
 * this should be changed so that the function is realistic and different according to the risk group of the two partners */
int time_to_partnership_dissolution(parameters *param, int r1, int r2){ //// IF WE WANT SOMETHING ASYMETRICAL ACCORDING TO GENDER WILL NEED TO SPECIFY WHICH IS THE MALE AND WHICH IS THE FEMALE
	//int t_partnership_dissolution = (int) (gsl_ran_exponential (rng, param->breakup_scale_lambda)* N_TIME_STEP_PER_YEAR);
	/* For Weibull(lambda,k) k=1 corresponds to the exponential dist. k<1 means prob of failure decreases over time, k>1 means increases over time. */
	//int t_partnership_dissolution = (int) (gsl_ran_weibull(rng, param->breakup_scale_lambda, param->breakup_shape_k)* N_TIME_STEP_PER_YEAR);
	//printf("Using Weibull\n");
	/* Using Gamma distribution: */
	int t_partnership_dissolution = (int) (gsl_ran_gamma (rng,param->breakup_scale_lambda, param->breakup_shape_k)* N_TIME_STEP_PER_YEAR);
	return t_partnership_dissolution;
}

/* Function does: breakup a given partnership and updates the lists of available partners and of serodiscordant couples accordingly
 * function arguments: the time at which partnership is broken up (double), a pointer to the partnership breaking up, pointers to the lists of pop_available_partners and n_pop_available_partners and susceptible_in_serodiscordant_partnership and n_susceptible_in_serodiscordant_partnership
 * Function returns: nothing */
void breakup(double time_breakup, partnership* breakup, population_partners* pop_available_partners, population_size *n_pop_available_partners, individual** susceptible_in_serodiscordant_partnership, long *n_susceptible_in_serodiscordant_partnership)
{
	if(breakup->ptr[0]->id==FOLLOW_INDIVIDUAL || breakup->ptr[1]->id==FOLLOW_INDIVIDUAL)
	{
		printf("Partnership breakup between individuals %ld and %ld\n",breakup->ptr[0]->id,breakup->ptr[1]->id);
		fflush(stdout);
	}
	
	if(breakup->ptr[0]->cd4 > DEAD && breakup->ptr[1]->cd4 > DEAD) /* onyly breakup partnership if the two individuals are alive */
	{
	
		// static long int n_breakups = 0; // for debug to count the number of breakups and check that all partnerships are broken up at some point
		int g;
		long index_partner;
		long id_partners[N_GENDER]; /*  contains the id of the 2 partners */
		for(g=0 ; g<N_GENDER ; g++)
		{
			id_partners[g] = breakup->ptr[g]->id;
		}
		
		individual *male = breakup->ptr[0];
		individual *female = breakup->ptr[1];

		individual *who = male;
		individual *other = female;

		/* Printing id of partners */
		//printf("Partnership between male %ld and female %ld will be dissolved\n",id_partners[0],id_partners[1]);
		//fflush(stdout);

		/* update of lists needs to be done before partnership does not exist anymore */
		
		update_list_available_partners_breakup(time_breakup, breakup, pop_available_partners, n_pop_available_partners);
		
		update_list_susceptibles_in_serodiscordant_partnerships_breakup(breakup, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership);
		
		/* removing the female from list of partners of the male and vice versa*/
		for(g=0 ; g<N_GENDER ; g++)
		{
			if(g==1)
			{
				who = female;
				other = male;
			}
			index_partner = 0;
			
			while(who->partner_pairs[index_partner]->ptr[1-g]->id!=id_partners[1-g])
			{
				index_partner++;
			}
			
			/* decreasing the number of partners by 1 */
			who->n_partners--;
			/* copying the last partner in place of this one - NOTE FOR DEBUGGING: AC does this the opposite way to MP who firstly swaps with the n-1 entry and then decreases n. */
			who->partner_pairs[index_partner] = who->partner_pairs[who->n_partners];
			/* same within the list of HIV positive partners if the partner is HIV positive */

			if(who->HIV_status==0 && other->HIV_status>0) /* only bother if the couple is serodiscordant */
			{
				index_partner = 0;
				while(who->partner_pairs_HIVpos[index_partner]->ptr[1-g]->id!=id_partners[1-g])
				{
					index_partner++;
				}
				who->n_HIVpos_partners--;
				who->partner_pairs_HIVpos[index_partner] = who->partner_pairs_HIVpos[who->n_HIVpos_partners];
			}
		}

		// for debug to count the number of breakups and check that all partnerships are broken up at some point:
		/*n_breakups++;
	printf("Simulated a total of: %ld breakups\n",n_breakups);
	fflush(stdout);*/

	}

}

/* Function does: updates the lists of available partners upon breakup of a partnership
 * function arguments: the time at which partnership is broken up (double), a pointer to the partnership breaking up, pointers to the lists of pop_available_partners and n_pop_available_partners
 * Function returns: nothing */
void update_list_available_partners_breakup(double time_breakup, partnership* breakup, population_partners* pop_available_partners, population_size *n_pop_available_partners){
	int g, ag, r;

	/* when breaking up a partnership, it needs to be removed and the partners need to be put back in the list of available partners */
	for(g=0 ; g<N_GENDER ; g++)
	{
		ag = get_age_group(breakup->ptr[g]->DoB, time_breakup);
		r = breakup->ptr[g]->sex_risk;
		/* Adding this person as an available partner in the list of available partners */
		pop_available_partners->pop_per_gender_age_risk[g][ag][r][n_pop_available_partners->pop_size_per_gender_age_risk[g][ag][r]] = breakup->ptr[g];
		/* Keeping track of where this person is in that list */
		breakup->ptr[g]->idx_available_partner[breakup->ptr[g]->max_n_partners - breakup->ptr[g]->n_partners] = n_pop_available_partners->pop_size_per_gender_age_risk[g][ag][r];
		n_pop_available_partners->pop_size_per_gender_age_risk[g][ag][r]++;
	}

}

/* Function does: add a susceptible to the list of serodiscordant partnership (can happen upon infection of a partner or partnership formation with an HIV infected individuals)
 * function arguments: a pointer to the susceptible individual, and pointers to the list of susceptible_in_serodiscordant_partnership and n_susceptible_in_serodiscordant_partnership
 * Function returns: nothing */
void add_susceptible_to_list_serodiscordant_partnership(individual* indiv, individual** susceptible_in_serodiscordant_partnership, long *n_susceptible_in_serodiscordant_partnership){
	indiv->idx_serodiscordant = n_susceptible_in_serodiscordant_partnership[0];
	susceptible_in_serodiscordant_partnership[n_susceptible_in_serodiscordant_partnership[0]] = indiv;
	n_susceptible_in_serodiscordant_partnership[0]++;
}

/* Function does: remove a susceptible to the list of serodiscordant partnership (can happen upon partnership breakup (including because death of partner) or seroconversion)
 * function arguments: a pointer to the susceptible individual, and pointers to the list of susceptible_in_serodiscordant_partnership and n_susceptible_in_serodiscordant_partnership
 * Function returns: nothing */
void remove_susceptible_from_list_serodiscordant_partnership(individual* indiv, individual** susceptible_in_serodiscordant_partnership, long *n_susceptible_in_serodiscordant_partnership){
	/* removing this susceptible from susceptible_in_serodiscordant_partnership and n_susceptible_in_serodiscordant_partnership */
	if((n_susceptible_in_serodiscordant_partnership[0]>0) && (indiv->idx_serodiscordant != -1))
	{
		susceptible_in_serodiscordant_partnership[indiv->idx_serodiscordant] = susceptible_in_serodiscordant_partnership[n_susceptible_in_serodiscordant_partnership[0] - 1]; /* pointing to the last susceptible instead of this one */
		/* changing the index of that partnership which has been "moved" from last */
		susceptible_in_serodiscordant_partnership[indiv->idx_serodiscordant]->idx_serodiscordant = indiv->idx_serodiscordant;
		n_susceptible_in_serodiscordant_partnership[0]--;
	}
}

/* Function does: updates the list of serodiscordant partnerships upon partnership breakup (the two individuals and their partners can enter or leave the list)
 * function arguments: a pointer to the partnership breaking up, and pointers to the list of susceptible_in_serodiscordant_partnership and n_susceptible_in_serodiscordant_partnership
 * Function returns: nothing */
void update_list_susceptibles_in_serodiscordant_partnerships_breakup(partnership* breakup, individual** susceptible_in_serodiscordant_partnership, long *n_susceptible_in_serodiscordant_partnership)
{
	/* if the partnership is serodiscordant and the susceptible has no other positive partners, removing the susceptible from susceptible_in_serodiscordant_partnership and n_susceptible_in_serodiscordant_partnership */
	int g;

	if(is_serodiscordant(breakup))
	{
		for(g=0 ; g<N_GENDER ; g++)
		{
			if(breakup->ptr[g]->HIV_status==0) /* this is the susceptible individual in the serodiscordant partnershipwhich is breaking up */
			{
				if(breakup->ptr[g]->n_HIVpos_partners==1) /* this means once this partnership has broken up the susceptible will have no more HIV+ partners */
				{
					/* then remove the susceptible from susceptible_in_serodiscordant_partnership and n_susceptible_in_serodiscordant_partnership */
					remove_susceptible_from_list_serodiscordant_partnership(breakup->ptr[g], susceptible_in_serodiscordant_partnership,  n_susceptible_in_serodiscordant_partnership);
				}
			}
		}

	}
}

/* Function does: fills in param->balanced_nb_f_to_m with the number of new partnerships between a female of age ag_f, risk r_f and a male of age ag_m, risk r_m over a time unit
 * function arguments: pointers to the population_size, the stratified_population_size, and the parameters
 * Function returns: nothing
 * NOTE: the functions used within this are defined in utilities.c */
void draw_nb_new_partnerships(population_size *n_pop, stratified_population_size *n_pop_strat, parameters *param)
{
	calcul_n_new_partners_f_to_m(n_pop, n_pop_strat, param);
	calcul_n_new_partners_m_to_f(n_pop, n_pop_strat, param);
	balance_contacts_arithmetic(param);
}

/* Function does: forms a certain number of partnerships (n) between given age/risk groups in men and women, and updates all the lists accordingly
 * function arguments:
 * 			the time of partnerthip formation
 * 			the number of partnerships to form
 * 			the age and risk group of the female and male respectively
 * 			a pointer to an integer (n_non_matchable) which will be filled in with the number of partnership we failed to form
 * 			a pointer to the individual_population (not used but helpful to have to be able to follow what happens to specific individuals when debugging code)
 * 			pointers to pop_available_partners and n_pop_available_partners
 *			pointers to n_pop and n_pop_strat
 *			pointers to partner_pairs and n_partnerships
 *			a pointer to parameters
 *			pointers to shuffled_idx, new_partners_f_sorted, new_partners_f_non_matchable, new_partners_m, partner_dummylist (used to store indexes of individuals randomly chosen to form partnerships)
 *			pointers to the list of planned_breakups and n_planned_breakups
 *			pointers to the list of susceptible_in_serodiscordant_partnership and n_susceptible_in_serodiscordant_partnership
 * Function returns: nothing
 * NOTE: individuals selected for partnership formation are chosen from those who have "available partnerships" */
void draw_n_new_partnerships(int time, long n, int ag_f, int r_f, int ag_m, int r_m, int *n_non_matchable, individual *individual_population,
		population_partners* pop_available_partners, population_size *n_pop_available_partners,
		population_size *n_pop, stratified_population_size *n_pop_strat,
		partnership* partner_pairs, long *n_partnerships,
		parameters *param, long *shuffled_idx, long* new_partners_f_sorted,
		long* new_partners_f_non_matchable, long *new_partners_m,  long *new_partners_m_sorted,  long *partner_dummylist,
		partnership*** planned_breakups, long *n_planned_breakups, long *size_planned_breakups,
		individual** susceptible_in_serodiscordant_partnership, long *n_susceptible_in_serodiscordant_partnership){

	long k = 0;
	int i, j;
	long initial_selected_male;
	int tmp;
	int idx_found;

	/* initialising n_non_matchable to zero: this will then be incremented to output the number of partnerships (out of n) that failed to form */
	*n_non_matchable = 0;

	//// ONCE WE HAVE DEBUGGED EVErYTHING SHOULD BE ABLE To GER RID OF idx_found and test on positivity of j.
	//// leaving it for now as is useful for debugging

	/* Only run this if we draw 1 or more partnerships. */
	if(n>0)
	{

		/* draw the female partners */
		gsl_ran_choose (rng, new_partners_f_sorted, n, partner_dummylist, n_pop_available_partners->pop_size_per_gender_age_risk[FEMALE][ag_f][r_f], sizeof (long));
		copy_array_long(shuffled_idx, partner_dummylist, n); /* copies  partner_dummylist in shuffled_idx */

		/* draw the male partners */
		gsl_ran_choose (rng, new_partners_m, n, partner_dummylist, n_pop_available_partners->pop_size_per_gender_age_risk[MALE][ag_m][r_m], sizeof (long));

		/* shuffle female partners as gsl_ran_choose sorts them by increasing index, to allow real random mixing with males who are also sorted by increasing index */
		gsl_ran_shuffle (rng, shuffled_idx, n,sizeof (long));


		for(k=0 ; k<n ; k++)
		{
			//printf("k = %d out of %d partnerships to draw\n", k,n);
			//fflush(stdout);

			/* check who these people are */
			//print_individual(pop_available_partners->pop_per_age_risk_per_gender[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]);
			//print_individual(pop_available_partners->pop_per_age_risk_per_gender[MALE][ag_m][r_m][new_partners_m[k]]);
			//fflush(stdout);

			/* Check that individuals are not already in a partnership with each other */
			if(are_in_partnership(pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]], pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]) ==1)
			{
				//printf("Individuals are already in a partnership with each other:\n");
				//print_individual(pop_available_partners->pop_per_age_risk_per_gender[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]);
				//print_individual(pop_available_partners->pop_per_age_risk_per_gender[MALE][ag_m][r_m][new_partners_m[k]]);
				//fflush(stdout);
				//getchar();

				/* if finding this male already as a partner, choose a different one in the same age/risk group: */
				initial_selected_male = new_partners_m[k];
				/* take the next one in the list that is not yet in a partnership with this female and has free partnerships */
				if(new_partners_m[k] < n_pop_available_partners->pop_size_per_gender_age_risk[MALE][ag_m][r_m] - 1)
				{
					do
					{
						new_partners_m[k]++;
					}while((new_partners_m[k] < n_pop_available_partners->pop_size_per_gender_age_risk[MALE][ag_m][r_m] - 1) && ((are_in_partnership(pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]], pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]) ==1) || (is_already_selected(new_partners_m, k, n)==1)));
				}

				/* if not possible, start back from male 0 in that group */
				if((are_in_partnership(pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]], pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]) ==1) || (is_already_selected(new_partners_m, k, n)==1))
				{
					new_partners_m[k] = 0;
					/* if not possible, take the next one in the list that is not yet in a partnership with this female and has a free partnership, up to the initially selected one */
					while( (new_partners_m[k] < initial_selected_male) && ((are_in_partnership(pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]], pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]) ==1) || (is_already_selected(new_partners_m, k, n)==1)))
					{
						new_partners_m[k]++;
					}
				}

				if(pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->id != pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][initial_selected_male]->id) /* if able to find an available male in this group which is not already in a partnership with this female */
				{
					/* form a partnership */
					//printf("Selected new male and creating partnership between:\n");
					//print_individual(pop_available_partners->pop_per_age_risk_per_gender[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]);
					//print_individual(pop_available_partners->pop_per_age_risk_per_gender[MALE][ag_m][r_m][new_partners_m[k]]);
					//fflush(stdout);
					new_partnership(&partner_pairs[*n_partnerships],pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]], pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]], time, planned_breakups, n_planned_breakups, size_planned_breakups, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership, param);
					(*n_partnerships) ++;

					/* remove the corresponding idx_available_partnership right away, for females */
					idx_found = 0;
					for(i=0 ; i<=pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->max_n_partners - pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->n_partners ; i++)
					{
						if(pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->idx_available_partner[i] == new_partners_f_sorted[shuffled_idx[k]])
						{
							idx_found = 1;
							break;
						}
					}
					if(idx_found==0)
					{
						printf("problem a here, idx should have been found that has not (female indirectly chosen)\n");
						fflush(stdout);
					}
					pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->idx_available_partner[i] = pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->idx_available_partner[pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->max_n_partners - pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->n_partners];
					pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->idx_available_partner[pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->max_n_partners - pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->n_partners] = -1;
					/* and for males */
					idx_found = 0;
					for(i=0 ; i<=pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->max_n_partners - pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->n_partners ; i++)
					{
						if(pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->idx_available_partner[i] == new_partners_m[k])
						{
							idx_found = 1;
							break;
						}
					}
					if(idx_found==0)
					{
						printf("problem a here, idx should have been found that has not (male indirectly chosen)\n");
						fflush(stdout);
					}
					pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->idx_available_partner[i] = pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->idx_available_partner[pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->max_n_partners - pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->n_partners];
					pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->idx_available_partner[pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->max_n_partners - pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->n_partners] = -1;


				}
				else
				{
					new_partners_f_non_matchable[*n_non_matchable] = k;
					(*n_non_matchable)++;

				}
			}else /* if the initially selected male was not already in a partnership with this female */
			{
				/* form a partnership */
				new_partnership(&partner_pairs[*n_partnerships],pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]], pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]], time,  planned_breakups, n_planned_breakups, size_planned_breakups, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership, param);
				(*n_partnerships)++;
				/* remove the corresponding idx_available_partnership right away, for females */
				idx_found = 0;
				for(i=0 ; i<=pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->max_n_partners - pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->n_partners ; i++)
				{
					if(pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->idx_available_partner[i] == new_partners_f_sorted[shuffled_idx[k]])
					{
						idx_found = 1;
						break;
					}
				}
				if(idx_found==0)
				{
					printf("problem here b, idx should have been found that has not (female directly chosen)\n");
					fflush(stdout);
				}
				pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->idx_available_partner[i] = pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->idx_available_partner[pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->max_n_partners - pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->n_partners];
				pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->idx_available_partner[pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->max_n_partners - pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[shuffled_idx[k]]]->n_partners] = -1;
				/* and for males */
				idx_found = 0;
				for(i=0 ; i<=pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->max_n_partners - pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->n_partners ; i++)
				{
					if(pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->idx_available_partner[i] == new_partners_m[k])
					{
						idx_found = 1;
						break;
					}
				}
				if(idx_found==0)
				{
					printf("problem here b, idx should have been found that has not (male directly chosen)\n");
					fflush(stdout);
				}
				pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->idx_available_partner[i] = pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->idx_available_partner[pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->max_n_partners - pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->n_partners];
				pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->idx_available_partner[pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->max_n_partners - pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m[k]]->n_partners] = -1;

			}
		}

		/* copies new_partners_m into new_partners_m_sorted */
		copy_array_long(new_partners_m_sorted, new_partners_m, n);

		/* sort new_partners_m_sorted (which can be not sorted if initial selected man was not selected in the end) */
		qsort(new_partners_m_sorted, n, sizeof(long), compare_longs);

		/* Remove individuals from the list of available partnerships, starting by the last ones, excluding those that we weren't able to match */
		for(k=n - 1 ; k>=0 ; k--)
		{
			/* removing females */
			tmp = 0;
			for(i=0 ; i<(*n_non_matchable) ; i++)
			{
				if(k==shuffled_idx[new_partners_f_non_matchable[i]])
				{
					tmp = 1;
					break;
				}
			}
			if(tmp==0)
			{
				/* removing this partnership with this female from the list of available partnerships */
				if(new_partners_f_sorted[k]<n_pop_available_partners->pop_size_per_gender_age_risk[FEMALE][ag_f][r_f] - 1)
				{
					pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[k]] = pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][n_pop_available_partners->pop_size_per_gender_age_risk[FEMALE][ag_f][r_f] - 1]; /* pointing to the last female instead of the current one */
					j = pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[k]]->max_n_partners - pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[k]]->n_partners - 1;
					while(j>=0 && pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[k]]->idx_available_partner[j] != n_pop_available_partners->pop_size_per_gender_age_risk[FEMALE][ag_f][r_f] - 1)
					{
						j--;
					}
					if(j<0)
					{
						printf("Problem here j negative1\n");
						fflush(stdout);
					}
					pop_available_partners->pop_per_gender_age_risk[FEMALE][ag_f][r_f][new_partners_f_sorted[k]]->idx_available_partner[j] = new_partners_f_sorted[k]; /* telling the person that has moved that they have. */
				}
				n_pop_available_partners->pop_size_per_gender_age_risk[FEMALE][ag_f][r_f]--; /* decreasing the number of available females in that group by 1 */
			}
			/* removing males */
			tmp = 0;
			for(i=0 ; i<(*n_non_matchable) ; i++)
			{
				if(new_partners_m_sorted[k]==new_partners_m[new_partners_f_non_matchable[i]])
				{
					tmp = 1;
					break;
				}
			}
			if(tmp==0)
			{
				/* removing this male from the list of available partnerships */
				if(new_partners_m_sorted[k]<n_pop_available_partners->pop_size_per_gender_age_risk[MALE][ag_m][r_m] - 1)
				{
					pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m_sorted[k]] = pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][n_pop_available_partners->pop_size_per_gender_age_risk[MALE][ag_m][r_m] - 1]; /* pointing to the last male instead of the current one */
					j = pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m_sorted[k]]->max_n_partners - pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m_sorted[k]]->n_partners - 1;
					while(j>=0 && pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m_sorted[k]]->idx_available_partner[j] != n_pop_available_partners->pop_size_per_gender_age_risk[MALE][ag_m][r_m] - 1)
					{
						j--;
					}
					if(j<0)
					{
						printf("Problem here j negative2\n");
						fflush(stdout);
					}
					pop_available_partners->pop_per_gender_age_risk[MALE][ag_m][r_m][new_partners_m_sorted[k]]->idx_available_partner[j] = new_partners_m_sorted[k]; /* telling the person that has moved that they have. */
				}
				n_pop_available_partners->pop_size_per_gender_age_risk[MALE][ag_m][r_m]--; /* decreasing the number of available males in that group by 1 */
			}

		}
	}
}

/* Function does: calculate the number of new partnerships to be drawn in a time step and forming these partnerships + updating all the lists
 * function arguments:
 * 			the time of partnerthip formation
 * 			a pointer to the individual_population (not used but helpful to have to be able to follow what happens to specific individuals when debugging code)
 * 			pointers to pop_available_partners and n_pop_available_partners
 *			pointers to n_pop and n_pop_strat
 *			pointers to partner_pairs and n_partnerships
 *			a pointer to parameters
 *			pointers to shuffled_idx, new_partners_f_sorted, new_partners_f_non_matchable, new_partners_m, partner_dummylist (used to store indexes of individuals randomly chosen to form partnerships)
 *			pointers to the list of planned_breakups and n_planned_breakups
 *			pointers to the list of susceptible_in_serodiscordant_partnership and n_susceptible_in_serodiscordant_partnership
 * Function returns: nothing */
void draw_new_partnerships(int time, individual *individual_population, population_partners* pop_available_partners, population_size *n_pop_available_partners,
		population_size *n_pop, stratified_population_size *n_pop_strat,
		partnership* partner_pairs, long *n_partnerships, parameters *param,
		long *shuffled_idx, long* new_partners_f_sorted, long* new_partners_f_non_matchable,
		long *new_partners_m, long *new_partners_m_sorted,  long *partner_dummylist,
		partnership*** planned_breakups, long *n_planned_breakups, long *size_planned_breakups,
		individual** susceptible_in_serodiscordant_partnership, long *n_susceptible_in_serodiscordant_partnership){

	int ag_f, ag_m,r_f, r_m;
	int n_non_matchable;
	int tmp = 0;
	int index = 0;

	draw_nb_new_partnerships(n_pop, n_pop_strat, param);

	for(ag_f=0 ; ag_f<N_AGE ; ag_f++)
	{
		for(r_f=0 ; r_f<N_RISK ; r_f++)
		{
			for(ag_m=0 ; ag_m<N_AGE ; ag_m++)
			{
				for(r_m=0 ; r_m<N_RISK ; r_m++)
				{
					index = 0;

					//printf("ag_f = %d \t r_f = %d \t ag_m = %d \t r_m = %d \n", ag_f,r_f,ag_m,r_m);
					//printf("Individual %ld's first index for available partner is: %ld\n",individual_population[10013].id,individual_population[10013].idx_available_partner[0]);
					//printf("Number of partnerships to be drawn %ld\n", param->balanced_nb_f_to_m[ag_f][r_f][ag_m][r_m]);
					//printf("Number of available partnerships from females %ld\n", n_pop_available_partners->pop_size_per_age_risk_per_gender[FEMALE][ag_f][r_f]);
					//printf("Number of available partnerships from males %ld\n", n_pop_available_partners->pop_size_per_age_risk_per_gender[MALE][ag_m][r_m]);
					//fflush(stdout);

					////////////////////////////////////////
					///// IN CASE WE MAY DRAW A NUMBER OF PARTNERSHIPS LARGER THAN THE AVAILABILITY,
					///// FOR NOW ARTIFICIALLY REDUCING THE NUMBER OF PARTNERSHIPS TO BE DRAWN BUT THIS MAY NEED FURTHER THINKING
					if(param->balanced_nb_f_to_m[ag_f][r_f][ag_m][r_m] > n_pop_available_partners->pop_size_per_gender_age_risk[FEMALE][ag_f][r_f])
					{
						//getchar();
						param->balanced_nb_f_to_m[ag_f][r_f][ag_m][r_m] = n_pop_available_partners->pop_size_per_gender_age_risk[FEMALE][ag_f][r_f];
					}
					if(param->balanced_nb_f_to_m[ag_f][r_f][ag_m][r_m] > n_pop_available_partners->pop_size_per_gender_age_risk[MALE][ag_m][r_m])
					{
						//getchar();
						param->balanced_nb_f_to_m[ag_f][r_f][ag_m][r_m] = n_pop_available_partners->pop_size_per_gender_age_risk[MALE][ag_m][r_m];
					}
					////////////////////////////////////////

					draw_n_new_partnerships(time, param->balanced_nb_f_to_m[ag_f][r_f][ag_m][r_m], ag_f,  r_f,  ag_m,  r_m, &n_non_matchable, individual_population, pop_available_partners, n_pop_available_partners, n_pop, n_pop_strat, partner_pairs, n_partnerships, param, shuffled_idx, new_partners_f_sorted, new_partners_f_non_matchable, new_partners_m,  new_partners_m_sorted, partner_dummylist, planned_breakups, n_planned_breakups, size_planned_breakups, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership);
					tmp = n_non_matchable;
					/* if some of the pairs could not be formed because they were already in a partnership together and we couldn't find another suitable male for that female, we redraw the corresponding number of pairs */
					while(tmp>0 && index<10) /// HERE THE CONDITION index<10 is to avoid an infinite loop, think better about how to deal with the case where it's just impossible to form a new partnership (e.g. 1 available partner in each group but they are already in partnership)
					{
						index++;
						draw_n_new_partnerships(time, n_non_matchable, ag_f,  r_f,  ag_m,  r_m, &tmp, individual_population, pop_available_partners, n_pop_available_partners, n_pop, n_pop_strat, partner_pairs, n_partnerships, param, shuffled_idx, new_partners_f_sorted, new_partners_f_non_matchable, new_partners_m, new_partners_m_sorted, partner_dummylist, planned_breakups, n_planned_breakups, size_planned_breakups, susceptible_in_serodiscordant_partnership, n_susceptible_in_serodiscordant_partnership);
						n_non_matchable = tmp;
					}
					if(index==10)
					{
						printf("Warning: some of the partnerships between males in age group %d, risk group %d and females in age group %d, risk group %d couldn't be formed.\n",ag_m,r_m,ag_f,r_f);
						fflush(stdout);
					}
				}
			}
		}
	}
}
